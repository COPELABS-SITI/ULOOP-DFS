/*
 * main.c
 *
 *  Created on: 26 de Fev de 2013
 *      Author: luis
 */

#include <time.h>
#include "unixsk/unixsk.h"
#include "uloop_message_api.h"


#include "cryptoid.h"
#include "idhelper.h"

static void print_bytes_mac(const unsigned char *hash, size_t size)
{
	int i = 0;
	for (i = 0; i < size; i++) {
		if (i != (size-1))
			fprintf(stderr, "%02x:", hash[i]);
		else
			fprintf(stderr, "%02x", hash[i]);
	}
	fprintf(stderr, "\n");
}

static void ask_enough_resources_request(int id,struct cryptoid *cid, double token)
{
	int conn = connect_to_resource_manager();
	uint8_t res = 0, macaddress[MAC_ADDRESS_SIZE] = {0xff, 0x00, 0xff, 0x00, 0xff, 0x00};//, received_macadress[MAC_ADDRESS_SIZE];
	printf("Teste");
	if (id == 1) {
		macaddress[0]=0xc0;
		macaddress[1]=0xd9;
		macaddress[2]=0x62;
		macaddress[3]=0x4d;
		macaddress[4]=0x52;
		macaddress[5]=0x86;
	}
	if (id == 0) {
		macaddress[0]=0x9c;
		macaddress[1]=0xb7;
		macaddress[2]=0x0d;
		macaddress[3]=0x45;
		macaddress[4]=0x9c;
		macaddress[5]=0x32;
	}
	if (id == 2) {
		macaddress[0]=0x70;
		macaddress[1]=0xf1;
		macaddress[2]=0xa1;
		macaddress[3]=0x04;
		macaddress[4]=0x4c;
		macaddress[5]=0xd7;
	}


	/* initialize random seed: */
	srand ( time(NULL) );

	if (token == 0) {
		/* generate token */
		token = (rand() % 3) + 1;
		printf ("%f",token);
	}

	if (conn != -1) {
		send_enough_resources_request(conn, cid, macaddress, token);
		recv_enough_resources_reply(conn, &res);
		printf("Enough resource is %s\n", res == 0 ? "false" : "true");
		//printf("Virtual interface mac address:\n");
		//print_bytes_mac(received_macadress, MAC_ADDRESS_SIZE);
	}
}

static int use_recv_generic_messages(struct cryptoid *cid)
{
	UloopMessage *ulm = NULL;
	int conn = recv_uloop_unix_msg(&ulm);

	if (ulm != NULL) {
		switch (uloop_message_type(ulm)) {
			case ULOOP_MESSAGE_TYPE__ULOOP_TRUSTMESSAGE:

				//mobility_requested_trust_information(conn, ulm);
				break;
			default:
				return 0;
		}
	}
	if(ulm)
		free_uloop_message(ulm);
	return 1;
}

int main(int argc,char *argv[]) {
	/*TMClient();
	int result = TMServer();
	if(!result){
		printf("TM: Request not accepted!\n");
	}
	else
		printf("TM: Request accepted!\n");
	return 0;*/
	struct cryptoid	*cid;
	double token;

	if (atoi(argv[1]) == 0)
		cid = create_crypto_ID(ULOOP_CERT_PATH);
	if (atoi(argv[1]) == 1)
		cid = create_crypto_ID("/usr/share/cert/client2.crt");
	if (atoi(argv[1]) == 2)
		cid = create_crypto_ID("/usr/share/cert/client3.crt");
	if (!cid) {
			fprintf(stderr, "Error reading file %s\n", ULOOP_CERT_PATH);
			return -1;
		}

	init_module(TM_MODULE);

	token = atof(argv[2]);

	ask_enough_resources_request(atoi(argv[1]),cid, token);

	//while(use_recv_generic_messages(cid));

	close_module(TM_MODULE);
	free(cid);

	return 0;
}
