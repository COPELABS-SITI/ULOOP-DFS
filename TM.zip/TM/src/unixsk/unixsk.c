/*
 * unixsk.c
 *
 *  Created on: 13 de Mar de 2013
 *      Author: luis
 */

#include <stdio.h>
#include <sys/socket.h>
#include <sys/un.h>
#include "unixsk.h"
/**
 * cacServer - creates a server based on UNIX sockets to receive requests from the cooperation
 * manager.
 */

int TMServer()
{
	int s, s2, t, len;
	struct sockaddr_un local, remote;
	char str[100];
	if ((s = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {
		perror("socket");
		exit(1);
	}

	local.sun_family = AF_UNIX;
	strcpy(local.sun_path, SOCK_PATH2);
	unlink(local.sun_path);
	len = strlen(local.sun_path) + sizeof(local.sun_family);
	if (bind(s, (struct sockaddr *)&local, len) == -1) {
		perror("bind");
		exit(1);
	}

	if (listen(s, 5) == -1) {
		perror("listen");
		exit(1);
	}
	for(;;) {
		int done, n;
		printf("Waiting for a connection...\n");
		t = sizeof(remote);
		if ((s2 = accept(s, (struct sockaddr *)&remote, &t)) == -1) {
			perror("accept");
			exit(1);
		}

		printf("Connected Server.\n");

		done = 0;
		do {
			n = recv(s2, str, 100, 0);
			if (n <= 0) {
				if (n < 0) perror("recv");
				done = 1;
			}
			done = 1;

		} while (!done);

		close(s2);
		printf("TM from RM: %s\n",str);
		return atoi(str);
	}
	return 0;
}

/**
 * cacClient - creates a client based on UNIX sockets, to send a request response to
 * the cooperation manager.
 */

void TMClient()
{
	int s, t, len;
	struct sockaddr_un remote;
	char str[100];

	if ((s = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {
		perror("socket");
		exit(1);
	}

	printf("Trying to connect...\n");

	remote.sun_family = AF_UNIX;
	strcpy(remote.sun_path, SOCK_PATH);
	len = strlen(remote.sun_path) + sizeof(remote.sun_family);
	if (connect(s, (struct sockaddr *)&remote, len) == -1) {
		perror("connect");
		exit(1);
	}

	printf("Connected Client.\n");

	while(printf("> "), fgets(str, 100, stdin), !feof(stdin)) {
		if (send(s, str, strlen(str), 0) == -1) {
			perror("send");
			exit(1);
		}
		break;
	}

	close(s);
}
