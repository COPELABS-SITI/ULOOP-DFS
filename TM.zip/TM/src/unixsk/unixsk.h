/*
 * unixsk.h
 *
 *  Created on: 13 de Mar de 2013
 *      Author: luis
 */

#ifndef UNIXSK_H_
#define UNIXSK_H_

#include <sys/socket.h>

#define SOCK_PATH "echo_socket"
#define SOCK_PATH2 "echo_socket2"


/* Server for connections that came from Cooperation Manager */
int TMServer();
/* Client to give a result to the Cooperation Manager */
void TMClient();

#endif /* UNIXSK_H_ */
