/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <netdb.h>
#include <unistd.h>

#include "uloop_core_functionality.h"

#include "uloop_message_api.h"

#define NUMBER_OF_MODULES 6

struct module_info modules[NUMBER_OF_MODULES] = {
			{	.path = "/var/run/uloop/rm_socket",
				.waiting_socket = -1,
			},
			{	.path = "/var/run/uloop/tm_socket",
				.waiting_socket = -1,
			},
			{	.path = "/var/run/uloop/mem_socket",
				.waiting_socket = -1,
			},
			{	.path = "/var/run/uloop/cac_socket",
				.waiting_socket = -1,
			},
			{	.path = "/var/run/uloop/mob_socket",
				.waiting_socket = -1,
			},
			{	.path = "/var/run/uloop/qos_socket",
				.waiting_socket = -1,
			},
		};

MODULES registered_module = NO_MODULE;

struct module_info * get_module_by_id(MODULES mod)
{
	if (mod < 0 || mod > NUMBER_OF_MODULES)
		return NULL;
	else
		return &modules[mod];
}

int __connect_to_unix_socket_by_name(int sk, const char *filename)
{
	struct sockaddr_un sun;
	char path[MAX_PATH];

	int len, res;

	if (sk == -1)
		return -1;

	sun.sun_family = AF_UNIX;
	strcpy(path, "/var/run/uloop/");
	strcat(path, filename);
	strcpy(sun.sun_path, path);

	len = strlen(sun.sun_path) + sizeof(sun.sun_family);
	res = connect(sk, (struct sockaddr *) &sun, len);

	if (res == -1) {
		fprintf(stderr, "connect error: %d connecting to %s with error %s\n", errno, path, strerror(errno));
		return -1;
	}
	return sk;
}

int connect_to_unix_socket(int sk, MODULES mod)
{
	struct sockaddr_un sun;
	int len, res;
	struct module_info *modi = get_module_by_id(mod);

	if (sk == -1)
		return -1;

	if (!modi)
		return -1;

	sun.sun_family = AF_UNIX;
	strcpy(sun.sun_path, modi->path);

	len = strlen(sun.sun_path) + sizeof(sun.sun_family);
	res = connect(sk, (struct sockaddr *) &sun, len);

	if (res == -1) {
		fprintf(stderr, "connect error: %d connecting to %s with error %s\n", errno, modi->path, strerror(errno));
		return -1;
	}
	return sk;

}

int init_module_server(struct module_info *modi)
{
	int res;
	struct sockaddr_un sun;

	if (modi->waiting_socket == -1)
		return -1;

	sun.sun_family = AF_UNIX;
	strcpy(sun.sun_path, modi->path);
	unlink(sun.sun_path); /* here to clean previous usages*/

	res = bind(modi->waiting_socket, (struct sockaddr *) &sun, strlen(sun.sun_path) + sizeof(sun.sun_family));
	if (res == -1) {
		fprintf(stderr, "bind error: %d binding to %s with error %s\n", errno, modi->path, strerror(errno));
		return -1;
	}

	listen(modi->waiting_socket, 2);

	return 0;
}
