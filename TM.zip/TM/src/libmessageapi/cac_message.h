/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#ifndef __ULOOP_CAC_MESSAGE_H__
#define __ULOOP_CAC_MESSAGE_H__

#include "cryptoid.h"

int __send_enough_resources_cac_reply(int sk, struct cryptoid *cid, double token, uint8_t enough);
UloopMessage *__create_resources_request(struct cryptoid *cid, double token, uint8_t enough);
int __recv_enough_resources_cac_reply(int sk, struct cryptoid *cid, double *token, uint8_t *enough);
int __recv_enough_resources_cac_reply_message(UloopMessage *ulm, struct cryptoid *cid, double *token, uint8_t *enough);
#endif
