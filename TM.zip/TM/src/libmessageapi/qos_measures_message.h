/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#ifndef __ULOOP_QOSMEASURES_MESSAGE_H__
#define __ULOOP_QOSMEASURES_MESSAGE_H__

int __send_measurement_request(int sk, const char *measurement_request);
UloopMessage * __create_measurement_request(const char *measurement_request);
int __recv_measurement_request(int sk, char *measurement_request);
int __recv_measurement_request_message(UloopMessage *ulm, char *measurement_request);

int __send_average_qos_measurements(int sk, const char *client_ip, const char *avgdelay, const char *avgbitrate, const char *avgpktloss, const char *avgjitter);
UloopMessage * __create_average_qos_measurements(const char *client_ip, const char *avgdelay, const char *avgbitrate, const char *avgpktloss, const char *avgjitter);
int __recv_average_qos_measurements(int sk, char *client_ip, char *avgdelay, char *avgbitrate, char *avgpktloss, char *avgjitter);


#endif
