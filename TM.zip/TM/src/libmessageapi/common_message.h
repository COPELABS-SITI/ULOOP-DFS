/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#ifndef __ULOOP_COMMON_H__
#define __ULOOP_COMMON_H__

#include "uloop.pb-c.h"

ssize_t __send_uloop_unix_message(int fd, UloopMessage *ulm);
UloopMessage *__recv_uloop_unix_msgs(int fd);
void __free_uloop_message(UloopMessage *ulm);
UloopMessage * __create_uloop_message(UloopMessage *ulm);
#ifdef _MONITOR
UloopMessage *__recv_uloop_unix_msgs_monitor(int fd);
#endif /* _MONITOR */
#endif /* ULOOP COMMON */
