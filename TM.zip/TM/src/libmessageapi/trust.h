/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#ifndef __ULOOP_TRUST_H__
#define __ULOOP_TRUST_H__

#include "cryptoid.h"
#include "uloop.pb-c.h"

int __send_trust_information_request(int fd, struct cryptoid *map);
UloopMessage * __create_trust_information_request(struct cryptoid *map);
int __recv_trust_information_reply(int fd, double *token);
int __recv_trust_information_reply_message(UloopMessage *ulm, double *token);

void print_trust_information_reply_message(TrustMessage *msg, double *token);
#endif
