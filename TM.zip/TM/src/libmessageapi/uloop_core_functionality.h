/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#ifndef __ULOOP_MESSAGE_CORE_H__
#define __ULOOP_MESSAGE_CORE_H__

#include "uloop_message_api.h"

#define MAX_PATH 255

struct module_info {
	char path[MAX_PATH];
	int waiting_socket;
	/*union socket_union {
		struct sockaddr_un unix;
		struct sockaddr_in net;
		struct sockaddr_in6 net6;
	};*/
};

struct module_info * get_module_by_id(MODULES mod);
int connect_to_unix_socket(int sk, MODULES mod);
int __connect_to_unix_socket_by_name(int sk, const char *filename);
int init_module_server(struct module_info *modi);

#endif
