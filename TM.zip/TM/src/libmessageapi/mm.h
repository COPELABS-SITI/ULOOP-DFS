/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#ifndef __ULOOP_MM_MESSAGE_H__
#define __ULOOP_MM_MESSAGE_H__

int __send_network_status_request(int fd);
UloopMessage * __create_network_status_request();
int __recv_network_status_reply(int fd, long *uplink_bandwidth, long *available_bandwidth);
int __recv_network_status_reply_message(UloopMessage *ulm, long *uplink_bandwidth, long *available_bandwidth);

int __send_network_status_reply(int fd, long uplink_bandwidth, long available_bandwidth);
UloopMessage * __create_network_status_reply(long uplink_bandwidth, long available_bandwidth);
int __recv_network_status_request(int fd);
int __recv_network_status_request_message(UloopMessage *ulm);

#endif
