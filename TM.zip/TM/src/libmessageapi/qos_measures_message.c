/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdint.h>

#include "common_message.h"
#include "uloop.pb-c.h"

static void create_measurement_request(QosRequest *req, const char *measurement_request)
{
	req->request = strdup(measurement_request);
}

UloopMessage * __create_measurement_request(const char *measurement_request)
{
	UloopMessage ulm = ULOOP_MESSAGE__INIT;
	QoSMessage qosm = QO_SMESSAGE__INIT;
	QosRequest req = QOS_REQUEST__INIT;

	create_measurement_request(&req, measurement_request);
	qosm.req = &req;
	ulm.qos = &qosm;
	
	ulm.ult = ULOOP_MESSAGE_TYPE__ULOOP_QOSMESSAGE;

	return __create_uloop_message(&ulm);
}

int __send_measurement_request(int sk, const char *measurement_request)
{
	UloopMessage *ulm = __create_measurement_request(measurement_request);
	int ret = __send_uloop_unix_message(sk, ulm);
	__free_uloop_message(ulm);
	return ret;
}

int __recv_measurement_request_message(UloopMessage *ulm, char *measurement_request)
{
	QoSMessage *qosm = NULL;
	QosRequest *req = NULL;

	if (ulm) {
		qosm = ulm->qos;
		if (qosm) {
			req = qosm->req;
			if (req) {
				strcpy(measurement_request, req->request);
				return 0;
			}
		}
	}
	return -1;
}

int __recv_measurement_request(int sk, char *measurement_request)
{
	UloopMessage *ulm = __recv_uloop_unix_msgs(sk);

	/* TODO: check message type */

	/*
		if(ulm->type != MEASUREMENT_REQUEST)
			return -1;
	*/

	int ret = __recv_measurement_request_message(ulm, measurement_request);
	__free_uloop_message(ulm);
	return ret;
}

static void create_measurement_info(QoSTuple *tuple, const char *client_ip, const char *avgdelay, const char *avgbitrate, const char *avgpktloss, const char *avgjitter)
{
	tuple->clientip = strdup(client_ip);
	tuple->avgdelay = strdup(avgdelay);
	tuple->avgbitrate = strdup(avgbitrate);
	tuple->avgpktloss = strdup(avgpktloss);
	tuple->avgjitter = strdup(avgjitter);
}

UloopMessage * __create_average_qos_measurements(const char *client_ip, const char *avgdelay, const char *avgbitrate, const char *avgpktloss, const char *avgjitter)
{
	UloopMessage ulm = ULOOP_MESSAGE__INIT;
	QoSMessage qosm = QO_SMESSAGE__INIT;
	QoSTuple tuple = QO_STUPLE__INIT;

	create_measurement_info(&tuple, client_ip, avgdelay, avgbitrate, avgpktloss, avgjitter);
	qosm.tuple = &tuple;
	ulm.qos = &qosm;
	ulm.ult = ULOOP_MESSAGE_TYPE__ULOOP_QOSMESSAGE;

	return __create_uloop_message(&ulm);
}

int __send_average_qos_measurements(int sk, const char *client_ip, const char *avgdelay, const char *avgbitrate, const char *avgpktloss, const char *avgjitter)
{
	UloopMessage *ulm = __create_average_qos_measurements(client_ip, avgdelay, avgbitrate, avgpktloss, avgjitter);
	int ret = __send_uloop_unix_message(sk, ulm);
	__free_uloop_message(ulm);
	return ret;
}

int __recv_average_qos_measurements_message(UloopMessage *ulm, char *client_ip, char *avgdelay, char *avgbitrate, char *avgpktloss, char *avgjitter)
{
	QoSMessage *qosm = NULL;
	QoSTuple *tuple = NULL;

	if (ulm) {
		qosm = ulm->qos;
		if (qosm) {
			tuple = qosm->tuple;
			if (tuple) {
				strcpy(client_ip, tuple->clientip);
				strcpy(avgdelay, tuple->avgdelay);
				strcpy(avgbitrate, tuple->avgbitrate);
				strcpy(avgpktloss, tuple->avgpktloss);
				strcpy(avgjitter, tuple->avgjitter);
				return 0;
			}
		}
	}
	return -1;
}

int __recv_average_qos_measurements(int sk, char *client_ip, char *avgdelay, char *avgbitrate, char *avgpktloss, char *avgjitter)
{
	UloopMessage *ulm = __recv_uloop_unix_msgs(sk);
	int ret = __recv_average_qos_measurements_message(ulm, client_ip, avgdelay, avgbitrate, avgpktloss, avgjitter);
	__free_uloop_message(ulm);
	return ret;
}
