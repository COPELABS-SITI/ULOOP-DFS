/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#ifndef __ULOOP_RESOURCES_H__
#define __ULOOP_RESOURCES_H__

#include <stdint.h>
#include "uloop_message_api.h"
#include "cryptoid.h"

int __send_enough_resources_request(int fd, struct cryptoid *cid, uint8_t macaddress[MAC_ADDRESS_SIZE], double token);
UloopMessage * __create_enough_resources_request(struct cryptoid *cid, uint8_t macaddress[MAC_ADDRESS_SIZE], double token);
int __recv_enough_resources_reply(int fd, uint8_t *res);
int __recv_enough_resources_reply_message(UloopMessage *ulm, uint8_t *res);

int __send_enough_resources_reply(int fd, uint8_t res);
UloopMessage * __create_enough_resources_reply(uint8_t res);
int __recv_enough_resources_request(int fd, struct cryptoid *cid, uint8_t macaddress[MAC_ADDRESS_SIZE], double *token);
int __recv_enough_resources_request_message(UloopMessage *ulm, struct cryptoid *cid, uint8_t macaddress[MAC_ADDRESS_SIZE], double *token);

#endif
