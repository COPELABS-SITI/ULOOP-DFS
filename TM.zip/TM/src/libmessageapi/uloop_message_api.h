/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *  Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#ifndef __ULOOP_MESSAGE_API_H__
#define __ULOOP_MESSAGE_API_H__

#include "cryptoid.h"
#include "uloop.pb-c.h"

#define MAC_ADDRESS_SIZE 6

#define ULOOP_CERT_PATH "/usr/share/cert/client.crt"

typedef enum MODULES {
	NO_MODULE = -1,
	RM_MODULE = 0,
	TM_MODULE = 1,
	MEM_MODULE = 2,
	CAC_MODULE = 3,
	MOB_MODULE = 4,
	QOS_MODULE = 5
} MODULES;

/* Init the messaging infrastructure for each module */
int init_module(MODULES module);
void close_module(MODULES module);

/* Connect to a specific module */
int connect_to_resource_manager();
int connect_to_mem();
int connect_to_qos();
int connect_to_trust_manager();
int connect_to_unix_socket_by_name(const char *filename);

void close_connection(int conn);


/* Send and receive uloop messages */
ssize_t send_uloop_unix_msg(int fd, UloopMessage *ulm);
int recv_uloop_unix_msg(UloopMessage **ulm);


/* Create ULOOP Messages */
UloopMessage * create_resources_request(struct cryptoid *cid, double token, uint8_t enough);
UloopMessage * create_new_user_details(struct cryptoid *cid, double token, uint8_t macaddress[MAC_ADDRESS_SIZE]);
UloopMessage * create_network_status_mem_request();
UloopMessage * create_network_status_mem_reply(long uplink_bandwidth, long available_bandwidth);
UloopMessage * create_network_status_request();
UloopMessage * create_network_status_reply(long uplink_bandwidth, long available_bandwidth);
UloopMessage * create_trust_information_reply(double token);
UloopMessage * create_measurement_request(const char *measurement_request);
UloopMessage * create_average_qos_measurements(const char *client_ip, const char *avgdelay, const char *avgbitrate, const char *avgpktloss, const char *avgjitter);
UloopMessage * create_enough_resources_request(struct cryptoid *cid, uint8_t macaddress[MAC_ADDRESS_SIZE], double token);
UloopMessage * create_enough_resources_reply(uint8_t res);
UloopMessage * create_trust_information_request(struct cryptoid *map);

/* Parse contents of ULOOP Messages */
int parse_trust_information_request(UloopMessage *ulm, struct cryptoid *map);
int parse_enough_resources_request(UloopMessage *ulm, struct cryptoid *cid, uint8_t macaddress[MAC_ADDRESS_SIZE], double *token);
int parse_network_status_request(UloopMessage *ulm);
int parse_enough_resources_cac_reply(UloopMessage *ulm, struct cryptoid *cid, double *token, uint8_t *enough);
int parse_network_status_mem_request(UloopMessage *ulm);
int parse_new_user_details(UloopMessage *ulm, struct cryptoid *cid, double *token, uint8_t macaddress[MAC_ADDRESS_SIZE]);
int parse_measurement_request(UloopMessage *ulm, char *measurement_request);

void free_uloop_message(UloopMessage *ulm);

/* Determine message types for switch cases */
UloopMessageType uloop_message_type(UloopMessage *ulm);

/*
 * ULOOP Message wrappers, for sending, receiving messages
 */

/* trust information */
int send_trust_information_request(int conn, struct cryptoid *map);
int recv_trust_information_request(int conn, struct cryptoid *map);
int recv_trust_information_reply(int conn, double *token);
int send_trust_information_reply(int conn, double token);

/* enough resources */
int send_enough_resources_request(int conn, struct cryptoid *cid, uint8_t macaddress[MAC_ADDRESS_SIZE], double token);
int recv_enough_resources_request(int conn, struct cryptoid *cid, uint8_t macaddress[MAC_ADDRESS_SIZE], double *token);
int recv_enough_resources_reply(int conn, uint8_t *res);
int send_enough_resources_reply(int conn, uint8_t res);

/* network status */
int send_network_status_request(int conn);
int recv_network_status_request(int conn);
int recv_network_status_reply(int conn, long *uplink_bandwidth, long *available_bandwidth);
int send_network_status_reply(int conn, long uplink_bandwidth, long available_bandwidth);

/* cac */
int send_enough_resources_cac_reply(int conn, struct cryptoid *cid, double token, uint8_t enough);
int recv_enough_resources_cac_reply(int conn, struct cryptoid *cid, double *token, uint8_t *enough);

/* mem */
int send_network_status_mem_request(int conn);
int recv_network_status_mem_request(int conn);
int recv_network_status_mem_reply(int conn, long *uplink_bandwidth, long *available_bandwidth);
int send_network_status_mem_reply(int conn, long uplink_bandwidth, long available_bandwidth);

/* user details */
int send_new_user_details(int conn, struct cryptoid *cid, double token, uint8_t macaddress[MAC_ADDRESS_SIZE]);
int recv_new_user_details(int conn, struct cryptoid *cid, double *token, uint8_t macaddress[MAC_ADDRESS_SIZE]);

/* qos measurement */
int send_measurement_request(int conn, const char *measurement_request);
int recv_measurement_request(int conn, char *measurement_request);
int recv_average_qos_measurements(int conn, char *client_ip, char *avgdelay, char *avgbitrate, char *avgpktloss, char *avgjitter);
int send_average_qos_measurements(int conn, const char *client_ip, const char *avgdelay, const char *avgbitrate, const char *avgpktloss, const char *avgjitter);


#endif
