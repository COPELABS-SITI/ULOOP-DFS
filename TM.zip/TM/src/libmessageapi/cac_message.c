/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdint.h>

#include "common_message.h"
#include "uloop.pb-c.h"
#include "cryptoid.h"

static void create_resources_request_message(EnoughResourcesCACReply *ercr, struct cryptoid *cid, size_t cid_len, double token, uint8_t enough)
{
	
	ProtobufCBinaryData cid_bytes;
	cid_bytes.data = cid->cryptoid;
	cid_bytes.len = cid_len;

	ercr->cryptoid = cid_bytes;
	ercr->enough = enough;
	ercr->token = token;
}

UloopMessage *__create_resources_request(struct cryptoid *cid, double token, uint8_t enough)
{
	UloopMessage ulm = ULOOP_MESSAGE__INIT;
	ResourceMessage rmsg = RESOURCE_MESSAGE__INIT;
	EnoughResourcesCACReply ercr = ENOUGH_RESOURCES_CACREPLY__INIT;
	
	create_resources_request_message(&ercr, cid, CRYPTO_ID_SIZE, token, enough);
	rmsg.cac = &ercr;
	ulm.rm = &rmsg;
	ulm.ult = ULOOP_MESSAGE_TYPE__ULOOP_CAC_MESSAGE;
	
	return __create_uloop_message(&ulm);
}

int __send_enough_resources_cac_reply(int sk, struct cryptoid *cid, double token, uint8_t enough)
{
	UloopMessage *ulm = __create_resources_request(cid, token, enough);
	int ret = __send_uloop_unix_message(sk, ulm);
	__free_uloop_message(ulm);
	return ret;
}

int __recv_enough_resources_cac_reply_message(UloopMessage *ulm, struct cryptoid *cid, double *token, uint8_t *enough)
{
	ResourceMessage *rmsg = NULL;
	
	if (!ulm) {
		printf("Failed to receive UloopMessage\n");
		return -1;
	}

	if (!(ulm->rm)) {
		printf("Not a resources Message\n");
		return -1;
	}

	rmsg = ulm->rm;

	if (rmsg->cac) {
		EnoughResourcesCACReply *cac = rmsg->cac;
		memcpy(cid->cryptoid, cac->cryptoid.data, cac->cryptoid.len);
		*token = cac->token;
		*enough = cac->enough;
	} else
		return -1;

	return 0;
}

int __recv_enough_resources_cac_reply(int sk, struct cryptoid *cid, double *token, uint8_t *enough)
{
	UloopMessage *ulm = __recv_uloop_unix_msgs(sk);
	int ret = __recv_enough_resources_cac_reply_message(ulm, cid, token, enough);
	__free_uloop_message(ulm);
	return ret;
}
