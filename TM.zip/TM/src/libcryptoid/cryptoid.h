/*
 * Copyright (C) 2012 Caixa Magica Software.
 *
 * Authors:
 *	Alfredo Matos <alfredo.matos@caixamagica.pt>
 *	Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#ifndef CRYPTO_H_
#define CRYPTO_H_

#include <openssl/sha.h>
#include <openssl/x509.h>

#include <stdint.h>

#define SHOWHASH ((2 * SHA256_DIGEST_LENGTH) + 1)
#define CRYPTO_ID_SIZE (SHA256_DIGEST_LENGTH)

struct cryptoid
{
	uint8_t cryptoid[CRYPTO_ID_SIZE];
};

struct cryptoid *create_crypto_ID(const char *filename);
struct cryptoid *create_crypto_ID_str(unsigned char *cid_str); /* not implemented */
int compare_cryptoid(struct cryptoid *a, struct cryptoid *b);
unsigned char *get_cryptoid_bytes(struct cryptoid *cid);
#endif
