/*
 * Copyright (C) 2012 Caixa Magica Software.
 *
 * Authors:
 *	Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "nodeid.h"
#include "idhelper.h"
#include "cryptoid.h"

struct nodeid *create_node_id(struct cryptoid *cid, const unsigned char *addr, size_t addr_len)
{
	struct nodeid *nid = NULL;
	if (cid == NULL)
		goto clean;

	nid = malloc(sizeof(*nid));

	memset(&(nid->nodeid), 0, NODE_ID_SIZE);
	memcpy(&(nid->nodeid), &(cid->cryptoid), CRYPTO_ID_SIZE);

	
	unsigned char *tmp2 = nid->nodeid;
	unsigned char *tmp3 = tmp2 + CRYPTO_ID_SIZE;
	sha256(&tmp3, addr, addr_len);

	fprintf(stdout, "NodeID info:\n");
	print_bytes(nid->nodeid, NODE_ID_SIZE);
	fprintf(stdout, "\n");

	return nid;
clean:
	if (nid != NULL)
		free(nid);
	return NULL;
}

unsigned char *get_nodeid_bytes(struct nodeid *nid)
{
	return nid != NULL ? nid->nodeid : NULL;
}

int compare_nodeid(struct nodeid *a, struct nodeid *b)
{
	return __nodeid_compare(a, b);
}
