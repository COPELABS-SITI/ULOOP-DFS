/*
 * Copyright (C) 2012 Caixa Magica Software.
 *
 * Authors:
 *	Alfredo Matos <alfredo.matos@caixamagica.pt>
 *	Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#ifndef _IDHELPER_H
#define _IDHELPER_H

#include "cryptoid.h"
#include "nodeid.h"

int __nodeid_compare(struct nodeid *a, struct nodeid *b);
int __cryptoid_compare(struct cryptoid *a, struct cryptoid *b);

void sha256(unsigned char **outputBuffer, const unsigned char *data, size_t len);
void print_bytes(const unsigned char *hash, size_t size);
#endif
