/*
 * Copyright (C) 2012 Caixa Magica Software.
 *
 * Authors:
 *	Alfredo Matos <alfredo.matos@caixamagica.pt>
 *	Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#ifndef _NODEID_H_
#define _NODEID_H_

#include <openssl/sha.h>

#include "cryptoid.h"

#define NODE_ID_SIZE (2 * SHA256_DIGEST_LENGTH)

struct nodeid {
       	unsigned char nodeid[NODE_ID_SIZE];
};

struct nodeid * create_node_id(struct cryptoid *cid, const unsigned char *addr, size_t addr_len);
int compare_nodeid(struct nodeid *a, struct nodeid *b);
unsigned char *get_nodeid_bytes(struct nodeid *nid);
#endif
