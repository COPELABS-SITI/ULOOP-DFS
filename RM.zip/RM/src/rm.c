/*
 ============================================================================
 Name        : rm.c
 Author      : Luis Lopes (SITILABS, ULHT), Hassan Osman (UniK),
 	 	 	   Mursel Yildiz (TUB)
 Version     : 3.0.0
 Copyright   : ULOOP 2013
 Description : Resource Manager, task 3.2 / prototype version 3.0.0
 	 	 	   Skeleton of task 3.2.
 Date		 : June 2013
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <sys/un.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <unistd.h>

#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <strings.h>
#include <getopt.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <poll.h>
#include <stdarg.h>
#include <sys/stat.h>

#include <linux/netdevice.h>

#include "cac/cac.h"
#include "rm.h"
#include "idhelper.h"
#include "cryptoid.h"
#include "uloop_message_api.h"
#include "uloop.pb-c.h"
#include "wrapper.h"

#define MAX_PAYLOAD 1024
#define NETLINK_INIT_ESM 21

static struct sockaddr_nl src_addr, dst_addr;

static struct msghdr msg;
static struct iovec iov;
static int sock_fd;

static int conn_tm = -1;

static int turn = 0; // TO REMOVE, JUST FOR TESTING!

/*
 * 	============================================================================
 *  Initialization code
 *  ============================================================================
 */

void print_help(char *prgname) {
	printf("----------| HELP PAGE |------------\n");
	printf("usage:  %s Neighbor_AP_SSID Neigbor_AP_IP\n", prgname);
	printf("Example:  %s UCN-Netgear1 192.168.124.22\n",prgname);
	printf("-----------------------------------\n");

}

int isValidIpAddress(char *ipAddress)
{
    struct sockaddr_in sa;
    int result = inet_pton(AF_INET, ipAddress, &(sa.sin_addr));
    return result;

}

void initMM(){
    char *command_MM;
    asprintf(&command_MM, "MM &");
    //printf("Command_MM: %s \n", command_MM);
    if (system(command_MM))
    	printf("MM is started successfully \n");
    else
    	printf("MM error \n");
    if( command_MM != NULL)
        free(command_MM);
}

void initLB(int argc, char *argv[]){
	char *command_LB;
	switch (argc) {
        case 1:
            printf("No argument is provided, please check with -h option !\n");
            break;
        case 2:
            if (strcmp(argv[1],"-h")==0){
                print_help(argv[0]);
            }
            else{
                printf("Please try -h !\n");
            }
            break;
        case 3:
            if(!isValidIpAddress(argv[2])){
                printf("IP Address isn't in the form of X.X.X.X or X.X.X.X.X.X\n");
                break;
            }
            printf("SSID of the Neighbour AP: %s\n",argv[1]);
            printf("IP Address of the Neighbour AP: %s\n",argv[2]);
            asprintf(&command_LB, "LB %s %s &", argv[1], argv[2]);
            printf("Command_LB: %s \n", command_LB);
            system(command_LB);
            printf("LB is started successfully \n");
            if( command_LB != NULL){
                free(command_LB);
            }
            break;
        default:
            printf("Argument count could be maximal 3, please use -h \n");
            break;
	};
}


void initMM_node(){
    char *command_MM_node;
    asprintf(&command_MM_node, "./MM_node &");
    printf("command_MM_node: %s \n", command_MM_node);
    system(command_MM_node);
    if( command_MM_node != NULL){
        free(command_MM_node);
    }
    printf("MM_node is started successfully \n");
}

static int init_ESM(int mode)
{
	struct nlmsghdr *nlh = NULL;
	int resp = 0;

	sock_fd = socket(PF_NETLINK, SOCK_RAW, NETLINK_INIT_ESM);

	memset(&msg,0,sizeof(msg));
	memset(&src_addr, 0, sizeof(src_addr));
	src_addr.nl_family = AF_NETLINK;
	src_addr.nl_pid = getpid();
	src_addr.nl_groups = 0; // no multicast
	bind(sock_fd, (struct sockaddr*)&src_addr, sizeof(src_addr));

	memset(&dst_addr, 0, sizeof(dst_addr));
	dst_addr.nl_family = AF_NETLINK;
	dst_addr.nl_pid = 0; // 0 means kernel
	dst_addr.nl_groups = 0; // no multicast

	nlh = malloc(NLMSG_SPACE(MAX_PAYLOAD));

	/* Fill the netlink message header */
	nlh->nlmsg_len = NLMSG_SPACE(MAX_PAYLOAD);
	nlh->nlmsg_pid = getpid();
	nlh->nlmsg_flags = 0;

	memcpy(NLMSG_DATA(nlh),&mode, sizeof(mode));

	iov.iov_base = (void *)nlh;
	iov.iov_len = nlh->nlmsg_len;

	msg.msg_name = (void *)&dst_addr;
	msg.msg_namelen = sizeof(dst_addr);
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;
	sendmsg(sock_fd, &msg, 0);

	/* Read message from kernel */
	memset(nlh, 0, NLMSG_SPACE(MAX_PAYLOAD));
	recvmsg(sock_fd, &msg, 0);
	resp = atoi(NLMSG_DATA(nlh));
	if(!resp)
		printf("Error during ESM initialization.\n");
	if(resp==1)
		printf("ESM initializated as Gateway\n");
	if(resp==2)
		printf("ESM initializated as Station");
	close(sock_fd);
	return resp;
}

static int init_gateway(void)
{
	// Initialize LB and MM
	//initLB(argc, argv);
	initMM();

	// Run RM with CAC
	if (!initialization(&cac_info)){
		printf("CAC initialization error.\n");
		goto error;
	}

	if (!init_ESM(1))
		goto error;

	while(call_RM());
error:
	return 0;
}

static int init_station(void)
{
	// Initialize MM
	initMM_node();

	// Initialize ESM as a Station
	init_ESM(2);

	return 1;
}

static int init(enum operation_mode mode)
{
	switch(mode)
	{
		case MODE_GATEWAY:// Device is working as a Gateway
			fprintf(stderr, "Gateway mode: Init CAC and ESM(gateway mode)\n");
			if (!init_gateway()) {
				fprintf(stderr, "Error during the initialization as a gateway.\n");
				return 0;
			}
			break;
		case MODE_NODE:// Device is working as a Station
			fprintf(stderr, "Station mode: Init ESM(station mode)\n");
			if (!init_station()) {
				fprintf(stderr, "Error during the initialization as a station.\n");
				return 0;
			}
			break;
		default:
			return 0;
	}
	return 1;
}




int main() {
	init_module(RM_MODULE);
	printf("============================= Resource Manager =============================\n");

	if (!init(check_operation_mode()))
		fprintf(stderr, "RM Stop working.\n");

	close_module(RM_MODULE);
	return 0;
}


/*
 *  ============================================================================
 * 	Resource Management code
 * 	============================================================================
 */


static void create_vif(uint8_t **mac)
{
	FILE *in;
	*mac = malloc(100 * sizeof( **mac));
	char buff[100];

	if( (in = popen("uloop-create-aps.sh 1 | grep 'MAC' | awk -F ': ' '{print $2}'","r")))
	{
		while (fgets(buff, sizeof(buff), in)!= NULL)
		{
			printf ("MAC ADDRESS: %s\n", buff);
		}
		sprintf(*mac, "%s", buff);
		pclose(in);
	}
}

static void create_id(uint8_t cryptoid[])
{
	int i = 0;
	uint8_t XOR = 0;
	uint8_t v1 = 0;
	uint8_t v2 = 0;

	for(i = 0; i < 8 ;i++){
		XOR ^= cryptoid[i];
	}

	v1 = (XOR >> 4);
	v2 = (XOR << 4);
	v2 = v2 >> 4;
	XOR = v1 ^ v2;
	fprintf(stderr, "ID Field: "); fprintf(stderr, "%02x\n", XOR);
}

static void process_resource_message(int conn, UloopMessage *ulm)
{
	double token;
	struct cryptoid cid1;
	uint8_t macaddress[MAC_ADDRESS_SIZE];
	struct cac_message message;

	fprintf(stderr, "Is a resource message ? %s \n", ulm->rm != NULL ? "Yes" : "No");
	parse_enough_resources_request(ulm, &cid1, macaddress, &token);
	fprintf(stderr, "cryptoid: ");
	print_bytes(cid1.cryptoid, 32);
	create_id(cid1.cryptoid);
	//fprintf(stderr, "Mac address: ");
	//print_bytes(macaddress, MAC_ADDRESS_SIZE);
	fprintf(stderr, "Token value %f\n", token);

	printf("========= Calling CAC =========\n");
	message.token = (int)token;
	memcpy(message.cryptoid, cid1.cryptoid, CRYPTO_ID_SIZE);

	//TEST MAC ADDRESS. TO REMOVE

	if (turn == 1) {
		message.macAddress[0]=0xc0;
		message.macAddress[1]=0xd9;
		message.macAddress[2]=0x62;
		message.macAddress[3]=0x4d;
		message.macAddress[4]=0x52;
		message.macAddress[5]=0x86;
		turn = 2;
	} else {
		if (turn == 0) {
			message.macAddress[0]=0x9c;
			message.macAddress[1]=0xb7;
			message.macAddress[2]=0x0d;
			message.macAddress[3]=0x45;
			message.macAddress[4]=0x9c;
			message.macAddress[5]=0x32;
			turn = 1;
		} else {
			message.macAddress[0]=0x70;
			message.macAddress[1]=0xf1;
			message.macAddress[2]=0xa1;
			message.macAddress[3]=0x04;
			message.macAddress[4]=0x4c;
			message.macAddress[5]=0xd7;
		}
	}
	message.trust_level=(float)0;

	cac(&message, &cac_info);
	printf("=========== End CAC ===========\n");

	conn_tm = conn;
}

static void process_cac_message(UloopMessage *ulm)
{
	uint8_t enough;
	uint8_t *mac;
	struct cryptoid cid;
	double token;

	parse_enough_resources_cac_reply(ulm, &cid, &token, &enough);
	if (enough == 0) {
		create_vif(&mac);
		printf("CAC response: OK - Created 1 VIF!\n");
		free(mac);
		send_enough_resources_reply(conn_tm, 1);
		int conn_mem = connect_to_mem();
		//send_new_user_details(conn_mem, &cid, token);
	}
	else {
		printf("CAC response: NOT OK\n");
		send_enough_resources_reply(conn_tm, 0);
	}
}

static void process_mobility_message(int conn_m, UloopMessage *ulm)
{
	long uplink, available;
	int ret = 0, conn_mem = -1;

	parse_network_status_request(ulm);

	conn_mem = connect_to_mem();

	ret = send_network_status_mem_request(conn_mem);// 17(flowchart), Sending a request to M&M

	fprintf(stderr, "return value %d from send_network_status_mem_request\n", ret);

	// function 11 flowchart. Receiving info from M&M
	recv_network_status_mem_reply(conn_mem, &uplink, &available);

	fprintf(stderr, "On RM\n");
	fprintf(stderr, "Uplink bandwidth value received: %ld\n", uplink);
	fprintf(stderr, "Available bandwidth value received: %ld\n", available);
	send_network_status_reply(conn_m, uplink, available); // 18(flowchart), send the data to Mobility
}

int call_RM() {

	UloopMessage *ulm = NULL;
	int conn = -1;
	conn = recv_uloop_unix_msg(&ulm);

	if (ulm != NULL) {
		switch(uloop_message_type(ulm))
		{
			case ULOOP_MESSAGE_TYPE__ULOOP_CAC_MESSAGE://CAC response Accepted, 2->3(flowchart)
				fprintf(stderr, "====== Message from CAC ======\n");
				process_cac_message(ulm);
				break;
			case ULOOP_MESSAGE_TYPE__ULOOP_ENOUGH_RESOURCES://CAC call, 8->1(flowchart)
				fprintf(stderr, "====== Message from Trust ======\n");
				process_resource_message(conn, ulm);
				break;
			case ULOOP_MESSAGE_TYPE__ULOOP_MOBILITY_RM:// Mobility Request, 9->10(flowchart)
				fprintf(stderr, "======Message from Mobility ======\n");
				process_mobility_message(conn, ulm);
				break;
			default:
				return 0;
		}
	}
	if(ulm)
		free_uloop_message(ulm);
	return 1;
}




