/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *  	Alfredo Matos <alfredo.matos@caixamagica.pt>
 *  	Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

/*
* based on FON's code
*/

#include <string.h>
#include <uci.h>
#include "wrapper.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

enum operation_mode get_current_config_from_uci(void)
{
	struct uci_context *uci = uci_alloc_context();
	enum operation_mode mode;
	char ret[5];
	struct uci_ptr ptr_node = {
		.package = "uloop",
		.section = "role",
		.option = "node"
	};

	struct uci_ptr ptr_gateway = {
		.package = "uloop",
		.section = "role",
		.option = "gateway"
	};

	uci_load(uci, "uloop", NULL);

	memset(ret, 0, 5);

	if (!uci_lookup_ptr(uci, &ptr_node, NULL, false) && (ptr_node.flags & UCI_LOOKUP_COMPLETE)) {
		struct uci_element *e = ptr_node.last;
		if (e->type == UCI_TYPE_SECTION) {
			strncpy(ret, uci_to_section(e)->type, 4);
		} else if (e->type == UCI_TYPE_OPTION && ptr_node.o->type == UCI_TYPE_STRING) {
				strncpy(ret, ptr_node.o->v.string, 4);
			}
	}

	if(atoi(ret) == 1) {
		mode = MODE_NODE;
	}
	
	memset(ret, 0, 5);
	if (!uci_lookup_ptr(uci, &ptr_gateway, NULL, false) && (ptr_gateway.flags & UCI_LOOKUP_COMPLETE)) {
		struct uci_element *e = ptr_gateway.last;
		if (e->type == UCI_TYPE_SECTION) {
			strncpy(ret, uci_to_section(e)->type, 4);
		} else if (e->type == UCI_TYPE_OPTION && ptr_gateway.o->type == UCI_TYPE_STRING) {
				strncpy(ret, ptr_gateway.o->v.string, 4);
			}
	}

	if(atoi(ret) == 1) {
		mode = MODE_GATEWAY;
	}

	uci_free_context(uci);
	uci = NULL;

	return mode;
}

enum operation_mode check_operation_mode() {
	return get_current_config_from_uci();
/* types much match with enum or must be made to match */
}

int is_gateway() {
	enum operation_mode mode = check_operation_mode();

	if(mode == MODE_GATEWAY)
		return 1;
	return 0;
}

int is_node() {
	enum operation_mode mode = check_operation_mode();

	if(mode == MODE_NODE)
		return 1;
	return 0;
}
