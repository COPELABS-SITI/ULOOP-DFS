/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *	Alfredo Matos <alfredo.matos@caixamagica.pt>
 *  Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#ifndef __ULOOP_OPERATION_MODE_H__
#define __ULOOP_OPERATION_MODE_H__

enum operation_mode {
	MODE_GATEWAY 	= 0x01,
	MODE_NODE 	= 0x02,
};

enum operation_mode check_operation_mode();

int is_gateway();

int is_node();

#endif
