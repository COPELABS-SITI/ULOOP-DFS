/*
 ============================================================================
 Name        : cac.h
 Author      : Luis Lopes (SITILABS, ULHT)
 Version     : 3.0.0
 Copyright   : ULOOP 2013
 Description : Global headers for theCall Admission Control,
 	 	 	   task 3.2 / prototype version 3.0.0

 	 	 	   Changes since version 2.0.0:
 	 	 	   - CAC isn't implemented inside the hostapd. Now CAC is part of
 	 	 	   	 Resource Manager module.
 	 	 	   - Netlink communication with ESM.
 	 	 	   - Internal interface to Trust Manager module, by using the
 	 	 	   	 uloopmessageAPI, from CMS.
 	 	 	   - resourcemanagement.c and h removed.
 	 	 	   - Added the cryptoID.
 Date		 : June 2013
 ============================================================================
 */

#ifndef CAC_H_
#define CAC_H_

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include "pqueue.h"
#include "idhelper.h"
#include "cryptoid.h"



#ifndef ETH_ALEN
#define ETH_ALEN 6
#endif


struct cac_data {
	PQueue *q;
	int sta_assoc;
	int sta_max;
	pthread_t thread;
	int thread_running;
};

struct nlmsghdr *hdr;

struct cac_message {
	uint8_t cryptoid[CRYPTO_ID_SIZE];
	int token;
	int trust_level;
	int subchannels;
	uint8_t macAddress[ETH_ALEN];
};

#define SOCK_PATH "echo_socket"

/*TODO: checkResources checks if there are available resources
 * on the gateway to serve the request. It is therefore part
 * of the interface to Resource Allocation.
 */
int initialization();
int cac(struct cac_message *rm_request, struct cac_data *cac_info);
URequest * handleIncomingRequests(float tokens, uint8_t cryptoid[], uint8_t macAddress[]);
int checkRequests(struct cac_data *cac);
void ComputePriority(URequest *request);
void redirectRequest(URequest *request);
struct esm checkResources(URequest *request);
void queueRequest(PQueue *q, URequest *request);
void *do_smth_periodically(void *data);
float gettrustlevel(uint8_t cryptoid[]);
/*
 * Interfaces to other modules
 */

/* Server for connections that came from Cooperation Manager */
void cacServer(struct cac_data * cacdata);
/* Client to give a result to the Cooperation Manager */
void cacClient();
/* To and from ESM */
int sendRequestToESM(URequest *request);
int sendESMreplyToRM(int resp, struct esm *info);


#endif /* CAC_H_ */
