/*
 ============================================================================
 Name        : pqueue.h
 Author      : Luis Lopes (SITILABS, ULHT)
 Version     : 3.0.0
 Copyright   : ULOOP 2013
 Description : Global headers for the Priority queue,
 	 	 	   task 3.2 / prototype version 3.0.0
 Date		 : June 2013
 ============================================================================
*/

#ifndef __PQUEUE__H__
#define __PQUEUE__H__

#include <stdio.h>
#include "idhelper.h"
#include "cryptoid.h"

#define ETH_ALEN 6

/**
* Debugging macro .
*
* Checks for a NULL pointer, and prints the error message, source file and
* line via 'stderr' .
* If the check fails the program exits with error code (-1) .
*/
#define NP_CHECK(ptr) \
    { \
        if (NULL == (ptr)) { \
            fprintf(stderr, "%s:%d NULL POINTER: %s n", \
                __FILE__, __LINE__, #ptr); \
            exit(-1); \
        } \
    } \

#define DEBUG(msg) fprintf(stderr, "%s:%d %s", __FILE__, __LINE__, (msg))

//! esm struct
/*! esm is a struct that is required in Elastic Spectrum Management */
struct esm {
	uint8_t cryptoid[CRYPTO_ID_SIZE]; /*!< to identify the station/requestd */
	int codedbits; /*!< codedbits correspond to the bits to be provided when emitting to this station */
	double token;
};

/* Test structure */
typedef struct URequest_s{
	int index;
	uint8_t cryptoid[CRYPTO_ID_SIZE];
	uint8_t macAddress[ETH_ALEN];
	unsigned char * srccryptoid;
	unsigned char * dstcryptoid;
	float tokens;
	float trustlevel;
	int redirected; //=0
	float priority;
	// for ESM
	struct esm * elastic;
	struct ieee80211_mgmt *mgmt;
	size_t len;

} URequest;

//! PQueue_s struct
/*! Priority Queue Structure */
typedef struct PQueue_s {
    size_t size;  /*!< The actual size of heap at a certain time */
    size_t capacity; /*!< The amount of allocated memory for the heap */
    void **data; /*!< An array of (void*), the actual max-heap */
    float (*cmp)(const void *d1, const void *d2); /*!< A pointer to a comparator function, used to prioritize elements */
} PQueue;

/*
 *  Functions
 */

void test_delete(URequest *t);

/*!< Used two compare two elements */
float request_compare(const void *d1, const void *d2);

/*!< Allocates memory for a new Priority Queue.
Needs a pointer to a comparator function, thus establishing priorities. */
PQueue *pqueue_new(float (*cmp)(const void *d1, const void *d2), size_t capacity);

/*!< De-allocates memory for a given Priority Queue */
void pqueue_delete(PQueue *q);

/*!< Add an element inside the Priority Queue */
void pqueue_enqueue(PQueue *q, const void *data);

/*!< Removes the element with the greatest priority from within the Queue */
void *pqueue_dequeue(PQueue *q);

#endif
