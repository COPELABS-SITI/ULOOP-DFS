/*
 ============================================================================
 Name        : cac.c
 Author      : Luis Lopes (SITILABS, ULHT)
 Version     : 3.0.0
 Copyright   : ULOOP 2013
 Description : Call Admission Control, task 3.2 / prototype version 3.0.0

  	 	 	   Changes since version 2.0.0:
 	 	 	   - CAC isn't implemented inside the hostapd. Now CAC is part of
 	 	 	   	 Resource Manager module.
 	 	 	   - Netlink communication with ESM.
 	 	 	   - Internal interface to Trust Manager module, by using the
 	 	 	   	 uloopmessageAPI, from CMS.
 	 	 	   - resourcemanagement.c and h removed.
 	 	 	   - Added the cryptoID.
 Date		 : June 2013
 ============================================================================
 */

#include <stdio.h>
#include <sys/time.h>
#include <pthread.h>
#include <sys/socket.h>
#include <linux/netlink.h>
#include <sys/un.h>
#include <stdlib.h>


#ifndef ULOOP

#include <sys/socket.h>
#include <linux/netlink.h>
#include <sys/un.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "cac.h"
#include "pqueue.h"
#include "idhelper.h"
#include "cryptoid.h"
#include "uloop_message_api.h"

#include "uloop.pb-c.h"

#define NETLINK_TEST 22
#define MAX_PAYLOAD 1024
static struct sockaddr_nl src_addr, dst_addr;

static struct msghdr msg;
static struct iovec iov;
static int sock_fd;

//initialization
int initialization(struct cac_data *cac) {
	cac->q = pqueue_new(request_compare, 5);
	if (cac->q == NULL)
		return 0;
	cac->thread_running = 0;
	//tokensProv = 0;
	printf("CAC initializated.\n");
	return 1;
}

/**
 * cac - receive, queue and process the authorization request.
 * @param hapd
 * 	hostapd BSS data structure (the BSS to which the management frame was
 * sent to)
 * @param buf
 * 	management frame data (starting from IEEE 802.11 header)
 * @param len
 * 	length of frame data in octets
 * @return int
 * 	Return the value 0 if the gateway accept the request or the value 32 if not.
 */
int cac(struct cac_message *rm_request, struct cac_data *cac_info) {

	URequest *request = NULL;
	float token;
	uint8_t cryptoid[CRYPTO_ID_SIZE];
	pthread_t thread;

	srand(time(NULL));
	printf ("Receive a new auth request.\n");

	/* when a new request arrives,
	   computes the request priority and
	   places the request on the queue.*/

	token = rm_request->token;

	memcpy(cryptoid, &(rm_request->cryptoid), CRYPTO_ID_SIZE);
	printf ("Token: %f\n", token);

	request = handleIncomingRequests(token, cryptoid, rm_request->macAddress);

    // Compute the priority of the request.
    ComputePriority(request);
    printf ("Priority Calculated: %f\n", request->priority);

    //Queue the request inside the priority queue.
    queueRequest(cac_info->q, request);

    printf ("Request added to the queue.\n");

    if (!cac_info->thread_running)
    {
    	pthread_create(&thread, NULL, do_smth_periodically, cac_info);
    	cac_info->thread_running = 1;
    }

    return 0;
}

/**
 * handleIncomingRequests - Put the information from the beacon on a request structure
 * @param tokens
 * 	token sended by the station
 * @param trustlevel
 * 	trustlevel sended by the station
 * @param srccryptoid
 * 	crypoid sended by the station. In the prototype version is the MAC address of the station
 * @return URequest
 * 	Return a structure with all the information got from the beacon to further process.
 */
URequest * handleIncomingRequests (float tokens, uint8_t cryptoid[], uint8_t macAddress[]) {
	URequest *request=malloc(sizeof(URequest));

	request->index = (rand() % 10 + 1);
	request->tokens = tokens;

	request->trustlevel = gettrustlevel(cryptoid);
	printf ("Trustlevel: %f\n", request->trustlevel);

	request->redirected = 1;
	memcpy(&(request->cryptoid), cryptoid, CRYPTO_ID_SIZE);
	memcpy(&(request->macAddress), macAddress, ETH_ALEN);

	return request;
} // ends function handleIncomingRequests

/**
 * gettrustlevel - get the trust level from the trust management
 * @param cryptoid
 * 	user identification
 * @return float
 * 	a value between 0 and 1
 */
float gettrustlevel(uint8_t cryptoid[]) {
	//ToDo: Get the trust value (ee->er) from the trust table.
	return (float)rand()/(float)RAND_MAX;
}

/**
 * ComputePriority - computes the priority of a request based on trust level of the gateway to
 * the station and the token of the request
 * @param request
 * 	structure with all the information of a request
 */
void ComputePriority(URequest *request) {
	request->priority = request->tokens * request->trustlevel;
}

/**
 * checkRequests - checks if exists request in the queue.
 * If exist then return a request with higher priority.
 * @param q
 * 	A request queue.
 * @return int
 *
 */
int checkRequests(struct cac_data *cac){
	struct esm s;
	int noRequests = 0;
	URequest * request;
	int replycode;
	PQueue * q = cac->q;
	if (q->size != 0) {
		printf ("Queue not empty\n");
	    request = ((URequest*)pqueue_dequeue(q));
	    s = checkResources(request);
	    if (s.codedbits != 0) {
	    	replycode=0;
	    	printf("Resource->token: %f\n", s.token);
	    }
	    else {
	    // request cannot be served by this gateway but if this is not
	    // a redirect, we can try to redirect it
	    	if (request->redirected==0) {
	    		// step 6
	    		//redirectRequest(request);

	    		// if this gateway does not hold resources
	    		// but an overlapping and trusted gw has
	    		// acks MAC association but provides MAC of the
	    		// new gateway in the request - changes the dstMAC of the request
	    		replycode=0;
	    	}
	    	else
	    		replycode=32;
	    }
		printf("Replycode: %d\n", replycode);
		sendESMreplyToRM(replycode, &s);
	} else {
		printf("Queue empty\n");
		noRequests = 1;
	}
	return noRequests;
}

/**
 * redirectRequest - Tries to find a neighboring gateway to serve
 * the request.
 * @param q
 * 	the request to serve
 */
void redirectRequest(URequest *request){
	//TODO: Pick the request and tries to find the better gateway for him.
}

/**
 * queueRequest - queue the request.
 * @param q
 * 	Requests queue
 * @return request
 * 	request to queue
 */
void queueRequest(PQueue *q, URequest *request){
	pqueue_enqueue(q, request);
}

/**
 * checkResources - checks available resources in the gateway.
 * @param request
 * 	structure with all the information of a request
 * @return struct esm
 * 	Return a structure with the identification of the station in the gateway and
 * 	the number of coded bits to be used in the creation of superframe.
 */
struct esm checkResources(URequest *request){

	int resources = 0;
	struct esm rStation;

	printf("Send Request to ESM.\n");
	resources = sendRequestToESM(request);

	if (resources){
		//codedbits = (rand() % 10 + 1);
		memcpy(&(rStation.cryptoid), &(request->cryptoid), CRYPTO_ID_SIZE);
		rStation.codedbits = 1;
		rStation.token = request->tokens;
	}else{
		memset(&(rStation.cryptoid),0,CRYPTO_ID_SIZE);
		rStation.codedbits = 0;
		rStation.token = 0;
	}
	return rStation;
}
void *do_smth_periodically(void *data){
	int interval = 100000; //50000 -> half of one second
	int noRequests = 0;
	struct cac_data *cac = (struct cac_data *)data;
	printf("****** CAC Thread activated ******\n");
	while (noRequests == 0) {
		noRequests = checkRequests(cac);
		usleep(interval);
	}
	printf("****** CAC Thread ended ******\n");
	cac->thread_running = 0;
	return NULL;
}

/**
 * sendRequestToESM - Send the a request to ESM to check if exist resources to accept the station.
 */

int sendRequestToESM(URequest *request)
{
	struct nlmsghdr *nlh = NULL;
	struct cac_message cac;
	int resp = 0;

	memcpy(cac.macAddress, &(request->macAddress), ETH_ALEN);
	memcpy(cac.cryptoid, &(request->cryptoid), CRYPTO_ID_SIZE);
	cac.token = (int)(request->tokens*1000);

	sock_fd = socket(PF_NETLINK, SOCK_RAW, NETLINK_TEST);

	memset(&msg,0,sizeof(msg));
	memset(&src_addr, 0, sizeof(src_addr));
	src_addr.nl_family = AF_NETLINK;
	src_addr.nl_pid = getpid();
	src_addr.nl_groups = 0; // no multicast
	bind(sock_fd, (struct sockaddr*)&src_addr, sizeof(src_addr));

	memset(&dst_addr, 0, sizeof(dst_addr));
	dst_addr.nl_family = AF_NETLINK;
	dst_addr.nl_pid = 0; // 0 means kernel
	dst_addr.nl_groups = 0; // no multicast

	nlh = malloc(NLMSG_SPACE(MAX_PAYLOAD));

	/* Fill the netlink message header */
	nlh->nlmsg_len = NLMSG_SPACE(MAX_PAYLOAD);
	nlh->nlmsg_pid = getpid();
	nlh->nlmsg_flags = 0;

	memcpy(NLMSG_DATA(nlh),&cac, sizeof(cac));

	iov.iov_base = (void *)nlh;
	iov.iov_len = nlh->nlmsg_len;

	msg.msg_name = (void *)&dst_addr;
	msg.msg_namelen = sizeof(dst_addr);
	msg.msg_iov = &iov;
	msg.msg_iovlen = 1;
	sendmsg(sock_fd, &msg, 0);

	/* Read message from kernel */
	memset(nlh, 0, NLMSG_SPACE(MAX_PAYLOAD));
	recvmsg(sock_fd, &msg, 0);
	resp = atoi(NLMSG_DATA(nlh));
	if(!resp)
		printf("ESM response-NO: %d\n",resp);
	else
		printf("ESM response-YES: %d\n",resp);
	close(sock_fd);
	return resp;
}

int sendESMreplyToRM(int resp, struct esm *info)
{
	/* open socket and connect */
	struct cryptoid cid;
	int conn = connect_to_resource_manager();

	/* send message on open connection */
	memcpy(&cid,&(info->cryptoid),CRYPTO_ID_SIZE);
	send_enough_resources_cac_reply(conn, &cid, info->token, resp);

	/* close open connection */
	close_connection(conn);

	return 0;
}

#endif /* ULOOP */

