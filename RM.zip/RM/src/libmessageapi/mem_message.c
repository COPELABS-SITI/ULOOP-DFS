/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdint.h>

#include "common_message.h"
#include "uloop.pb-c.h"
#include "cryptoid.h"

#include "mem_message.h"
#include "uloop_message_api.h"

static void create_new_user_details_message(NewUserDetailsMessage *nudm, struct cryptoid *cid, double token)
{
	
	int cid_size = 32;
	ProtobufCBinaryData cryptoid_bytes;
	cryptoid_bytes.data = cid->cryptoid;
	cryptoid_bytes.len = cid_size;

	nudm->cryptoid = cryptoid_bytes;
	nudm->token = token;
}

UloopMessage * __create_new_user_details(struct cryptoid *cid, double token)
{
	UloopMessage ulm = ULOOP_MESSAGE__INIT;
	NewUserDetailsMessage nudm = NEW_USER_DETAILS_MESSAGE__INIT;
	
	create_new_user_details_message(&nudm, cid, token);
	ulm.udm = &nudm;
	ulm.ult = ULOOP_MESSAGE_TYPE__ULOOP_NEWUSERDETAILS;

	return __create_uloop_message(&ulm);
}

int __send_new_user_details(int sk, struct cryptoid *cid, double token)
{
	UloopMessage *ulm = __create_new_user_details(cid, token);
	int ret = __send_uloop_unix_message(sk, ulm);
	__free_uloop_message(ulm);
	return ret;
}

int __recv_new_user_details_message(UloopMessage *ulm, struct cryptoid *cid, double *token)
{
	NewUserDetailsMessage *nudm = NULL;
	
	if (!ulm) {
		printf("Failed to receive UloopMessage\n");
		return -1;
	}

	if (!(ulm->udm)) {
		fprintf(stderr, "Not a mem Message\n");
		return -1;
	}

	nudm = ulm->udm;

	if (nudm) {
		memcpy(cid->cryptoid, nudm->cryptoid.data, nudm->cryptoid.len);
		*token = nudm->token;
	} else
		return -1;

	return 0;

}

int __recv_new_user_details(int sk, struct cryptoid *cid, double *token)
{
	UloopMessage *ulm = __recv_uloop_unix_msgs(sk);
	int ret = __recv_new_user_details_message(ulm, cid, token);
	__free_uloop_message(ulm);
	return ret;
}

UloopMessage * __create_network_status_mem_request()
{
	UloopMessage ulm = ULOOP_MESSAGE__INIT;
	ulm.ult = ULOOP_MESSAGE_TYPE__ULOOP_NETWORKSTATUS;
	return __create_uloop_message(&ulm);
}

int __send_network_status_mem_request(int sk)
{
	UloopMessage *ulm = __create_network_status_mem_request();
	int ret = __send_uloop_unix_message(sk, ulm);
	__free_uloop_message(ulm);
	return ret;
}

int __recv_network_status_mem_request_message(UloopMessage *ulm)
{
	if (!ulm) {
		printf("Failed to receive UloopMessage\n");
		return -1;
	}

	return 0;
}

int __recv_network_status_mem_request(int sk)
{
	UloopMessage *ulm = __recv_uloop_unix_msgs(sk);
	int ret = __recv_network_status_mem_request_message(ulm);
	__free_uloop_message(ulm);
	return ret;
}

static void create_network_status_mem(NetworkStatusMessageReply *rsmr, long uplink_bandwidth, long available_bandwidth)
{
	rsmr->uplink = uplink_bandwidth;
	rsmr->available = available_bandwidth;
}

UloopMessage * __create_network_status_mem_reply(long uplink_bandwidth, long available_bandwidth)
{
	UloopMessage ulm = ULOOP_MESSAGE__INIT;
	NetworkStatusMessage nsm = NETWORK_STATUS_MESSAGE__INIT;
	NetworkStatusMessageReply rsmr = NETWORK_STATUS_MESSAGE_REPLY__INIT;

	create_network_status_mem(&rsmr, uplink_bandwidth, available_bandwidth);
	nsm.nsrep = &rsmr;
	ulm.nsm = &nsm;
	ulm.ult = ULOOP_MESSAGE_TYPE__ULOOP_MEM_RESOURCES;

	return __create_uloop_message(&ulm);
}

int __send_network_status_mem_reply(int sk, long uplink_bandwidth, long available_bandwidth)
{
	UloopMessage *ulm = __create_network_status_mem_reply(uplink_bandwidth, available_bandwidth);
	int ret =  __send_uloop_unix_message(sk, ulm);
	__free_uloop_message(ulm);
	return ret;
}

int __recv_network_status_mem_reply_message(UloopMessage *ulm, long *uplink_bandwidth, long *available_bandwidth)
{
	NetworkStatusMessage *nsm = NULL;
	
	if (!ulm) {
		printf("Failed to receive UloopMessage\n");
		return -1;
	}

	nsm = ulm->nsm;
	if (nsm) {
		NetworkStatusMessageReply *rsmr = nsm->nsrep;
		if (rsmr) {
			*uplink_bandwidth = rsmr->uplink;
			*available_bandwidth = rsmr->available;
		}
	}

	return 0;
}

int __recv_network_status_mem_reply(int sk, long *uplink_bandwidth, long *available_bandwidth)
{
	UloopMessage *ulm = __recv_uloop_unix_msgs(sk);
	int ret = __recv_network_status_mem_reply_message(ulm, uplink_bandwidth, available_bandwidth);
	__free_uloop_message(ulm);
	return ret;
}
