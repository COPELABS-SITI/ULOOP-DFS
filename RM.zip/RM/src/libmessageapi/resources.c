/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/socket.h>
#include <string.h>

#include "cryptoid.h"
#include "uloop.pb-c.h"
#include "common_message.h"
#include "resources.h"
#include "uloop_message_api.h"

static void create_resources_request_message(EnoughResourcesMessageRequest *erreq, struct cryptoid *cid, size_t cid_size, uint8_t macaddress[MAC_ADDRESS_SIZE], double token)
{
	ProtobufCBinaryData cryptoid_bytes;
	cryptoid_bytes.data = cid->cryptoid;
	cryptoid_bytes.len = cid_size;

	ProtobufCBinaryData mac_bytes;
	mac_bytes.data = macaddress;
	mac_bytes.len = MAC_ADDRESS_SIZE;

	erreq->cryptoid = cryptoid_bytes;
	erreq->macaddress = mac_bytes;
	erreq->token = token;
}

UloopMessage * __create_enough_resources_request(struct cryptoid *cid, uint8_t macaddress[MAC_ADDRESS_SIZE], double token)
{
	UloopMessage ulm = ULOOP_MESSAGE__INIT;
	ResourceMessage rmsg = RESOURCE_MESSAGE__INIT;
	EnoughResourcesMessageRequest erreq = ENOUGH_RESOURCES_MESSAGE_REQUEST__INIT;

	create_resources_request_message(&erreq, cid, 32, macaddress, token);
	rmsg.rreq = &erreq;
	ulm.rm = &rmsg;
	ulm.ult = ULOOP_MESSAGE_TYPE__ULOOP_ENOUGH_RESOURCES;
	return __create_uloop_message(&ulm);
}

int __send_enough_resources_request(int fd, struct cryptoid *cid, uint8_t macaddress[MAC_ADDRESS_SIZE], double token)
{
	UloopMessage *ulm = __create_enough_resources_request(cid, macaddress, token);
	int ret = __send_uloop_unix_message(fd, ulm);
	__free_uloop_message(ulm);
	return ret;
}

int __recv_enough_resources_reply_message(UloopMessage *ulm, uint8_t *res)
{
	ResourceMessage *rmsg = NULL;
	
	if (!ulm) {
		printf("Failed to receive UloopMessage\n");
		return -1;
	}

	if (!(ulm->rm)) {
		printf("Not a resources Message\n");
		return -1;
	}

	rmsg = ulm->rm;

	if (rmsg->rep) {
		EnoughResourcesMessageReply *ermr = rmsg->rep;
		*res = ermr->res;
	} else
		return -1;

	return 0;
}

int __recv_enough_resources_reply(int fd, uint8_t *res)
{
	UloopMessage *ulm = __recv_uloop_unix_msgs(fd);
	int ret = __recv_enough_resources_reply_message(ulm, res);
	__free_uloop_message(ulm);
	return ret;
}

int __recv_enough_resources_request_message(UloopMessage *ulm, struct cryptoid *cid, uint8_t macaddress[MAC_ADDRESS_SIZE], double *token)
{
	ResourceMessage *rmsg = NULL;
	
	if (!ulm) {
		printf("Failed to receive UloopMessage\n");
		return -1;
	}

	if (!(ulm->rm)) {
		printf("Not a resources Message\n");
		return -1;
	}

	rmsg = ulm->rm;

	if (rmsg->rreq) {
		EnoughResourcesMessageRequest *ermr = rmsg->rreq;
		memcpy(cid->cryptoid, ermr->cryptoid.data, ermr->cryptoid.len);
		memcpy(macaddress, ermr->macaddress.data, MAC_ADDRESS_SIZE);
		*token = ermr->token;
	}

	return 0;
}

int __recv_enough_resources_request(int fd, struct cryptoid *cid, uint8_t macaddress[MAC_ADDRESS_SIZE], double *token)
{	
	UloopMessage *ulm = __recv_uloop_unix_msgs(fd);
	int ret = __recv_enough_resources_request_message(ulm, cid, macaddress, token);
	__free_uloop_message(ulm);
	return ret;
}

static void create_resources_reply_message(EnoughResourcesMessageReply *errep, uint8_t res)
{
	errep->res = res;
}

UloopMessage * __create_enough_resources_reply(uint8_t res)
{
	UloopMessage ulm = ULOOP_MESSAGE__INIT;
	ResourceMessage rmsg = RESOURCE_MESSAGE__INIT;
	EnoughResourcesMessageReply errep = ENOUGH_RESOURCES_MESSAGE_REPLY__INIT;

	create_resources_reply_message(&errep, res);
	rmsg.rep = &errep;
	ulm.rm = &rmsg;
	ulm.ult = ULOOP_MESSAGE_TYPE__ULOOP_UNSPEC;
	return __create_uloop_message(&ulm);
}

int __send_enough_resources_reply(int fd, uint8_t res)
{
	UloopMessage *ulm = __create_enough_resources_reply(res);
	int ret = __send_uloop_unix_message(fd, ulm);
	__free_uloop_message(ulm);
	return ret;
}
