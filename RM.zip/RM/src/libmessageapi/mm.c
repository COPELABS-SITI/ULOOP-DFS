/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/socket.h>

#include "common_message.h"
#include "uloop.pb-c.h"
#include "mm.h"

UloopMessage * __create_network_status_request()
{
	UloopMessage ulm = ULOOP_MESSAGE__INIT;

	ulm.ult = ULOOP_MESSAGE_TYPE__ULOOP_MOBILITY_RM;

	return __create_uloop_message(&ulm);
}

int __send_network_status_request(int fd)
{
	UloopMessage *ulm = __create_network_status_request();
	int ret =  __send_uloop_unix_message(fd, ulm);
	__free_uloop_message(ulm);
	return ret;
}

int __recv_network_status_reply_message(UloopMessage *ulm, long *uplink_bandwidth, long *available_bandwidth)
{
	NetworkStatusMessage *nsmsg = NULL;
	
	if (!ulm) {
		fprintf(stderr, "Failed to unpack uloop message\n");
		return -1;
	}

	if (ulm->nsm)
		nsmsg = ulm->nsm;

	if (!nsmsg) {
		fprintf(stderr, "Not a network status reply\n");
		return -1;
	}

	if (nsmsg) {
		NetworkStatusMessageReply *nsrep = nsmsg->nsrep;
		if (nsrep) {
			*uplink_bandwidth = nsrep->uplink;
			*available_bandwidth = nsrep->available;
		}
	}

	return 0;
}

int __recv_network_status_reply(int fd, long *uplink_bandwidth, long *available_bandwidth)
{
	UloopMessage *ulm = __recv_uloop_unix_msgs(fd);
	int ret =  __recv_network_status_reply_message(ulm, uplink_bandwidth, available_bandwidth);
	__free_uloop_message(ulm);
	return ret;
}

int __recv_network_status_request_message(UloopMessage *ulm)
{
	if(!ulm) {
		printf("Failed to receive UloopMessage\n");
		return -1;
	}
			
	printf("Received network status message type %d\n", ulm->ult);

	return 0;
}

int __recv_network_status_request(int fd)
{
	UloopMessage *ulm = __recv_uloop_unix_msgs(fd);
	int ret = __recv_network_status_request_message(ulm);
	__free_uloop_message(ulm);
	return ret;
}

static void create_networkstatus_reply_message(NetworkStatusMessageReply *nsrep, long uplink_bandwidth, long available_bandwidth)
{
	nsrep->uplink = uplink_bandwidth;
	nsrep->available = available_bandwidth;
}

UloopMessage * __create_network_status_reply(long uplink_bandwidth, long available_bandwidth)
{
	UloopMessage ulm = ULOOP_MESSAGE__INIT;
	NetworkStatusMessage nsmsg = NETWORK_STATUS_MESSAGE__INIT;
	NetworkStatusMessageReply nsrep = NETWORK_STATUS_MESSAGE_REPLY__INIT;

	create_networkstatus_reply_message(&nsrep, uplink_bandwidth, available_bandwidth);
	nsmsg.nsrep = &nsrep;
	ulm.nsm = &nsmsg;
	ulm.ult = ULOOP_MESSAGE_TYPE__ULOOP_UNSPEC;

	return __create_uloop_message(&ulm);
}

int __send_network_status_reply(int fd, long uplink_bandwidth, long available_bandwidth)
{
	UloopMessage *ulm = __create_network_status_reply(uplink_bandwidth, available_bandwidth);
	int ret = __send_uloop_unix_message(fd, ulm);
	__free_uloop_message(ulm);
	return ret;
}
