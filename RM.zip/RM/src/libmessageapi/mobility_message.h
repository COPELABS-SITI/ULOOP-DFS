/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#ifndef __ULOOP_MOBILITY_MESSAGE_H__
#define __ULOOP_MOBILITY_MESSAGE_H__

#include "cryptoid.h"
#include "uloop.pb-c.h"

int __recv_trust_information_request_message(UloopMessage *ulm, struct cryptoid *map);
int __recv_trust_information_request(int fd, struct cryptoid *map);
int __send_trust_information_reply(int fd, double token);
UloopMessage * __create_trust_information_reply(double token);

void print_trust_information_request_message(TrustMessage *msg);
#endif
