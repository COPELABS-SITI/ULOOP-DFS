/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#ifndef __ULOOP_MEM_MESSAGE_H__
#define __ULOOP_MEM_MESSAGE_H__

#include "cryptoid.h"
#include "uloop_message_api.h"

int __send_new_user_details(int sk, struct cryptoid *cid, double token);
UloopMessage * __create_new_user_details(struct cryptoid *cid, double token);
int __recv_new_user_details(int sk, struct cryptoid *cid, double *token);
int __recv_new_user_details_message(UloopMessage *ulm, struct cryptoid *cid, double *token);
int __send_network_status_mem_request(int sk);
UloopMessage * __create_network_status_mem_request();
int __recv_network_status_mem_request(int sk);
int __recv_network_status_mem_request_message(UloopMessage *ulm);
int __send_network_status_mem_reply(int sk, long uplink_bandwidth, long available_bandwidth);
UloopMessage * __create_network_status_mem_reply(long uplink_bandwidth, long available_bandwidth);
int __recv_network_status_mem_reply(int sk, long *uplink_bandwidth, long *available_bandwidth);
int __recv_network_status_mem_reply_message(UloopMessage *ulm, long *uplink_bandwidth, long *available_bandwidth);
#endif
