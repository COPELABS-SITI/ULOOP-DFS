/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *	Alfredo Matos <alfredo.matos@caixamagica.pt>
 *  Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <netdb.h>
#include <unistd.h>

#include "uloop_message_api.h"
#include "uloop_core_functionality.h"
#include "uloop.pb-c.h"

#include "common_message.h"
#include "cryptoid.h"
#include "trust.h"
#include "mobility_message.h"
#include "qos_measures_message.h"

#include "resources.h"
#include "mm.h"
#include "cac_message.h"
#include "mem_message.h"

extern MODULES registered_module;

static int open_unix_socket()
{
	return socket(AF_UNIX, SOCK_STREAM, 0);
}

int connect_to_unix_socket_by_name(const char *filename)
{
	int sk = open_unix_socket();
	return __connect_to_unix_socket_by_name(sk, filename);
}

void free_uloop_message(UloopMessage *ulm)
{
	__free_uloop_message(ulm);
}

int init_module(MODULES module)
{
	struct module_info *modi;

	registered_module = module;

	modi = get_module_by_id(module);
	if (!modi)
		return -1;

	modi->waiting_socket = socket(AF_UNIX, SOCK_STREAM, 0);

	return init_module_server(modi);
}

void close_module(MODULES module)
{
	struct module_info *modi = get_module_by_id(module);
	if (modi)
		close(modi->waiting_socket);
}

void close_connection(int conn)
{
	close(conn);
}

int recv_uloop_unix_msg(UloopMessage **ulm)
{
	struct module_info *modi = get_module_by_id(registered_module);
	struct sockaddr_un peer;
	socklen_t peer_len = 0;
	int sk, nsk;

	if (!modi)
		return -1;

	sk = modi->waiting_socket;
	nsk = accept(sk, (struct sockaddr *) &peer, &peer_len);
	*ulm = __recv_uloop_unix_msgs(nsk);

	return nsk;
}

ssize_t send_uloop_unix_msg(int fd, UloopMessage *ulm)
{
	return __send_uloop_unix_message(fd, ulm);
}

UloopMessageType uloop_message_type(UloopMessage *ulm)
{
	if (ulm) {
		return ulm->ult;
	} else
		return ULOOP_MESSAGE_TYPE__ULOOP_UNSPEC;
}

int connect_to_resource_manager()
{
	int sk = open_unix_socket();
	return connect_to_unix_socket(sk, RM_MODULE);
}

int connect_to_trust_manager()
{
	int sk = open_unix_socket();
	return connect_to_unix_socket(sk, TM_MODULE);
}

int connect_to_mem()
{
	int sk = open_unix_socket();
	return connect_to_unix_socket(sk, MEM_MODULE);
}

int connect_to_qos()
{
	int sk = open_unix_socket();
	return connect_to_unix_socket(sk, QOS_MODULE);
}

int send_trust_information_request(int conn, struct cryptoid *map)
{
	return __send_trust_information_request(conn, map);
}

int recv_trust_information_request(int conn, struct cryptoid *map)
{
	return __recv_trust_information_request(conn, map);
}

int recv_trust_information_reply(int conn, double *token)
{
	int ret;
	int sk = conn;
	if (sk == -1)
		return -1;

	ret = __recv_trust_information_reply(sk, token);
	close(sk);
	return ret;
}

int parse_trust_information_request(UloopMessage *ulm, struct cryptoid *map)
{
	if(ulm->ult != ULOOP_MESSAGE_TYPE__ULOOP_TRUSTMESSAGE)
		return -1;
	return __recv_trust_information_request_message(ulm, map);
}

int send_trust_information_reply(int conn, double token)
{
	int sk = conn;
	if (sk == -1)
		return -1;

	__send_trust_information_reply(sk, token);
	close(sk);
	return 0;
}

/* enough resources */
int send_enough_resources_request(int conn, struct cryptoid *cid, uint8_t macaddress[MAC_ADDRESS_SIZE], double token)
{
	return __send_enough_resources_request(conn, cid, macaddress, token);
}

int recv_enough_resources_request(int conn, struct cryptoid *cid, uint8_t macaddress[MAC_ADDRESS_SIZE], double *token)
{
	return __recv_enough_resources_request(conn, cid, macaddress, token);
}

int recv_enough_resources_reply(int conn, uint8_t *res)
{
	int sk = conn;
	if (sk == -1)
		return -1;

	__recv_enough_resources_reply(sk, res);
	close(sk);
	return 0;
}

int parse_enough_resources_request(UloopMessage *ulm, struct cryptoid *cid, uint8_t macaddress[MAC_ADDRESS_SIZE], double *token)
{
	if(ulm->ult != ULOOP_MESSAGE_TYPE__ULOOP_ENOUGH_RESOURCES)
		return -1;
	return __recv_enough_resources_request_message(ulm, cid, macaddress, token);
}

int send_enough_resources_reply(int conn, uint8_t res)
{
	int sk = conn;
	if (sk == -1)
		return -1;

	__send_enough_resources_reply(sk, res);
	close(sk);
	return 0;
}

/* network status */
int send_network_status_request(int conn)
{
	return __send_network_status_request(conn);
}

int recv_network_status_request(int conn)
{
	return __recv_network_status_request(conn);
}

int recv_network_status_reply(int conn, long *uplink_bandwidth, long *available_bandwidth)
{
	int sk = conn;
	if (sk == -1)
		return -1;

	__recv_network_status_reply(sk, uplink_bandwidth, available_bandwidth);
	close(sk);
	return 0;
}

int parse_network_status_request(UloopMessage *ulm)
{
	if(ulm->ult != ULOOP_MESSAGE_TYPE__ULOOP_NETWORKSTATUS)
		return -1;
	return __recv_network_status_request_message(ulm);
}

int send_network_status_reply(int conn, long uplink_bandwidth, long available_bandwidth)
{
	int sk = conn;
	if (sk == -1)
		return -1;

	__send_network_status_reply(sk, uplink_bandwidth, available_bandwidth);
	close(sk);
	return 0;
}

/* cac */
int send_enough_resources_cac_reply(int conn, struct cryptoid *cid, double token, uint8_t enough)
{
	return __send_enough_resources_cac_reply(conn, cid, token, enough);
}

int recv_enough_resources_cac_reply(int conn, struct cryptoid *cid, double *token, uint8_t *enough)
{
	return __recv_enough_resources_cac_reply(conn, cid, token, enough);
}

int parse_enough_resources_cac_reply(UloopMessage *ulm, struct cryptoid *cid, double *token, uint8_t *enough)
{
	if(ulm->ult != ULOOP_MESSAGE_TYPE__ULOOP_CAC_MESSAGE)
		return -1;
	return __recv_enough_resources_cac_reply_message(ulm, cid, token, enough);
}

/* mem */
int send_network_status_mem_request(int conn)
{
	int sk = conn;
	return __send_network_status_mem_request(sk);
}

int recv_network_status_mem_request(int conn)
{
	return __recv_network_status_mem_request(conn);
}

int recv_network_status_mem_reply(int conn, long *uplink_bandwidth, long *available_bandwidth)
{
	int sk = conn;
	__recv_network_status_mem_reply(sk, uplink_bandwidth, available_bandwidth);
	close(sk);
	return 0;
}

int parse_network_status_mem_request(UloopMessage *ulm)
{
	if(ulm->ult != ULOOP_MESSAGE_TYPE__ULOOP_NETWORKSTATUS)
		return -1;
	return __recv_network_status_mem_request_message(ulm);
}

int send_network_status_mem_reply(int conn, long uplink_bandwidth, long available_bandwidth)
{
	int sk = conn;
	__send_network_status_mem_reply(sk, uplink_bandwidth, available_bandwidth);
	close(sk);
	return 0;
}

/* user details */
int send_new_user_details(int conn, struct cryptoid *cid, double token)
{
	int sk = conn;
	if (sk == -1)
		return -1;

	return __send_new_user_details(sk, cid, token);
}

int recv_new_user_details(int conn, struct cryptoid *cid, double *token)
{
	return __recv_new_user_details(conn, cid, token);
}

int parse_new_user_details(UloopMessage *ulm, struct cryptoid *cid, double *token)
{
	if(ulm->ult != ULOOP_MESSAGE_TYPE__ULOOP_NEWUSERDETAILS)
		return -1;
	__recv_new_user_details_message(ulm, cid, token);
	return 0;
}

/* qos measurement */
int send_measurement_request(int conn, const char *measurement_request)
{
	int sk = conn;
	return __send_measurement_request(sk, measurement_request);
}

int recv_measurement_request(int conn, char *measurement_request)
{
	return __recv_measurement_request(conn, measurement_request);
}

int recv_average_qos_measurements(int conn, char *client_ip, char *avgdelay, char *avgbitrate, char *avgpktloss, char *avgjitter)
{
	int sk = conn;
	__recv_average_qos_measurements(sk, client_ip, avgdelay, avgbitrate, avgpktloss, avgjitter);
	close(sk);
	return 0;
}

int parse_measurement_request(UloopMessage *ulm, char *measurement_request)
{
	if(ulm->ult != ULOOP_MESSAGE_TYPE__ULOOP_QOSMESSAGE)
		return -1;
	return __recv_measurement_request_message(ulm, measurement_request);
}

int send_average_qos_measurements(int conn, const char *client_ip, const char *avgdelay, const char *avgbitrate, const char *avgpktloss, const char *avgjitter)
{
	int sk = conn;
	if (sk == -1)
		return -1;

	__send_average_qos_measurements(sk, client_ip, avgdelay, avgbitrate, avgpktloss, avgjitter);
	close(sk);
	return 0;
}


UloopMessage * create_resources_request(struct cryptoid *cid, double token, uint8_t enough)
{
	return __create_resources_request(cid, token, enough);
}

UloopMessage * create_new_user_details(struct cryptoid *cid, double token)
{
	return __create_new_user_details(cid, token);
}

UloopMessage * create_network_status_mem_request()
{
	return __create_network_status_mem_request();
}

UloopMessage * create_network_status_mem_reply(long uplink_bandwidth, long available_bandwidth)
{
	return __create_network_status_mem_reply(uplink_bandwidth, available_bandwidth);
}

UloopMessage * create_network_status_request()
{
	return __create_network_status_request();
}

UloopMessage * create_network_status_reply(long uplink_bandwidth, long available_bandwidth)
{
	return __create_network_status_reply(uplink_bandwidth, available_bandwidth);
}

UloopMessage * create_trust_information_reply(double token)
{
	return __create_trust_information_reply(token);
}

UloopMessage * create_measurement_request(const char *measurement_request)
{
	return __create_measurement_request(measurement_request);
}

UloopMessage * create_average_qos_measurements(const char *client_ip, const char *avgdelay, const char *avgbitrate, const char *avgpktloss, const char *avgjitter)
{
	return __create_average_qos_measurements(client_ip, avgdelay, avgbitrate, avgpktloss, avgjitter);
}

UloopMessage * create_enough_resources_request(struct cryptoid *cid, uint8_t macaddress[MAC_ADDRESS_SIZE], double token)
{
	return __create_enough_resources_request(cid, macaddress, token);
}

UloopMessage * create_enough_resources_reply(uint8_t res)
{
	return __create_enough_resources_reply(res);
}

UloopMessage * create_trust_information_request(struct cryptoid *map)
{
	return __create_trust_information_request(map);
}
