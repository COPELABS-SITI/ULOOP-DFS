/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdint.h>

#include "common_message.h"
#include "uloop.pb-c.h"
#include "mobility_message.h"
#include "idhelper.h"

static void create_trust_information_reply_message(TrustInformationReply *tirr, double token)
{
	tirr->token = token;
}

int __recv_trust_information_request_message(UloopMessage *ulm, struct cryptoid *map)
{
	TrustMessage *tmsg = NULL;

	if (!ulm)
		return -1;

	if (ulm->tm)
		tmsg = ulm->tm;

	if (!tmsg)
		fprintf(stderr, "Not a trust message\n");

	if (tmsg) {
		TrustInformationRequest *tir = tmsg->treq;
		if (tir) {
			memcpy(map->cryptoid, tir->map.data, tir->map.len);
		}
	}
	__free_uloop_message(ulm);
			
	return 0;
}

int __recv_trust_information_request(int fd, struct cryptoid *map)
{

	UloopMessage *ulm = __recv_uloop_unix_msgs(fd);
	int ret = __recv_trust_information_request_message(ulm, map);
	__free_uloop_message(ulm);
	return ret;
}

UloopMessage * __create_trust_information_reply(double token)
{
	UloopMessage ulm = ULOOP_MESSAGE__INIT;
	TrustMessage tmsg = TRUST_MESSAGE__INIT;
	TrustInformationReply tirr = TRUST_INFORMATION_REPLY__INIT;

	create_trust_information_reply_message(&tirr, token);
	tmsg.trep = &tirr;
	ulm.tm = &tmsg;
	ulm.ult = ULOOP_MESSAGE_TYPE__ULOOP_UNSPEC;

	return __create_uloop_message(&ulm);
}

int __send_trust_information_reply(int fd, double token)
{
	UloopMessage *ulm = __create_trust_information_reply(token);
	int ret = __send_uloop_unix_message(fd, ulm);
	__free_uloop_message(ulm);
	return ret;
}

static void __print_trust_information_request_message(TrustInformationRequest *msg)
{
	fprintf(stdout, "Cryptoid from message map\n");
	print_bytes(msg->map.data ,32);
	fprintf(stdout, "\n");
}

void print_trust_information_request_message(TrustMessage *msg)
{
	if (msg->treq != NULL) {
		TrustInformationRequest *treq = msg->treq;
		__print_trust_information_request_message(treq);
	}
}
