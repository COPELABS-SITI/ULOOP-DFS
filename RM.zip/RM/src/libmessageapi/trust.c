/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdint.h>

#include "common_message.h"
#include "uloop.pb-c.h"
#include "trust.h"

static void create_trust_information_request_message(TrustInformationRequest *tirmsg, struct cryptoid *map, size_t map_len)
{
	ProtobufCBinaryData map_bytes;
	map_bytes.data = map->cryptoid;
	map_bytes.len = map_len;

	tirmsg->map = map_bytes;
}

UloopMessage * __create_trust_information_request(struct cryptoid *map)
{
	UloopMessage ulm = ULOOP_MESSAGE__INIT;
	TrustMessage tmsg = TRUST_MESSAGE__INIT;
	TrustInformationRequest tirmsg = TRUST_INFORMATION_REQUEST__INIT;

	create_trust_information_request_message(&tirmsg, map, 32);
	tmsg.treq = &tirmsg;
	ulm.tm = &tmsg;
	ulm.ult = ULOOP_MESSAGE_TYPE__ULOOP_TRUSTMESSAGE;

	return __create_uloop_message(&ulm);
}

int __send_trust_information_request(int fd, struct cryptoid *map)
{
	UloopMessage *ulm = __create_trust_information_request(map);
	int ret = __send_uloop_unix_message(fd, ulm);
	__free_uloop_message(ulm);
	return ret;
}

int __recv_trust_information_reply_message(UloopMessage *ulm, double *token)
{
	TrustMessage *tmsg = NULL;
	TrustInformationReply *trep = NULL;
	
	if (ulm)
		tmsg = ulm->tm;
	else {
		fprintf(stderr, "Failed to unpack uloop message\n");
		return -1;
	}
		
	if (!tmsg)
		fprintf(stderr, "Failed to unpack trust message\n");

	if (tmsg) {
		trep = tmsg->trep;
		*token = trep->token;
	}

	return 0;
}

int __recv_trust_information_reply(int fd, double *token)
{
	UloopMessage *ulm = __recv_uloop_unix_msgs(fd);
	int ret = __recv_trust_information_reply_message(ulm, token);
	__free_uloop_message(ulm);
	return ret;
}

static void __print_trust_information_reply_message(TrustInformationReply *msg)
{
	fprintf(stdout, "Token: %f\n", msg->token);
}

void print_trust_information_reply_message(TrustMessage *msg, double *token)
{
	if (msg->trep != NULL) {
		TrustInformationReply *trep = msg->trep;
		__print_trust_information_reply_message(trep);
	}
}
