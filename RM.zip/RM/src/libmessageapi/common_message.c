/*
 *  Copyright (C) 2013 Caixa Magica Software.
 *
 *  Authors:
 *      Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdint.h>
#include <sys/un.h>

#include "common_message.h"
#include "uloop.pb-c.h"
#include <google/protobuf-c/protobuf-c.h>

#define HEADER_MESSAGE_SIZE 5

void __free_uloop_message(UloopMessage *ulm)
{
	uloop_message__free_unpacked(ulm, NULL);
}

UloopMessage * __create_uloop_message(UloopMessage *ulm)
{
	UloopMessage *ret = NULL;
	uint8_t *buf = NULL;
	size_t size;

	size = uloop_message__get_packed_size(ulm);
	buf = malloc(size);
	uloop_message__pack(ulm, buf);
	ret = uloop_message__unpack(NULL, size, buf);
	free(buf);

	return ret;
}

static void create_header_message(UloopHeaderMessage *msg, size_t payload_length)
{
	msg->length = payload_length;
#ifdef ULOOP_DEBUG
	fprintf(stderr, "Payload size: %zd\n", payload_length);
#endif
}

static ssize_t send_header_message(int fd, void *msg)
{
	return send(fd, msg, HEADER_MESSAGE_SIZE, 0);
}

static ssize_t send_message(int fd, void *msg, ssize_t mlen)
{
	return send(fd, msg, mlen, 0);
}

ssize_t __send_uloop_unix_message(int fd, UloopMessage *ulm)
{
	uint8_t *buf_header = NULL, *buf_payload = NULL;
	UloopHeaderMessage msg = ULOOP_HEADER_MESSAGE__INIT;
	size_t length = HEADER_MESSAGE_SIZE, sent_data = 0, payload_length = 0;
	
	if (ulm) {
		payload_length = uloop_message__get_packed_size(ulm);
		create_header_message(&msg, payload_length);
	}
#ifdef ULOOP_DEBUG
	length = uloop_header_message__get_packed_size(&msg);
	fprintf(stderr, "ULOOP HEADER: %zd \n", length);
#endif

	buf_header = malloc(length);
	uloop_header_message__pack(&msg, buf_header);
	sent_data = send_header_message(fd, buf_header);

	if (payload_length > 0) {
		buf_payload = malloc(payload_length);
		uloop_message__pack(ulm, buf_payload);
		sent_data += send_message(fd, buf_payload, payload_length);
	}
	
	if (buf_header != NULL)
		free(buf_header);
	if (buf_payload != NULL)
		free(buf_payload);
	return sent_data;
}

#ifdef ULOOP_DEBUG
static void debug_hex_message(unsigned char *buf, int len)
{
	unsigned int i;

	fprintf(stderr, "Debug buffer:");

	for(i = 0; i < len; i++)
		fprintf(stderr, " %02x", buf[i]);

	fprintf(stderr, "\n");
}
#endif

#ifdef ULOOP_DEBUG
static void print_message_header(UloopHeaderMessage *msg)
{
	fprintf(stdout, "Message size: %u\n", msg->length);
}
#endif

static ssize_t recv_header_message(int fd, void *msg)
{
	return recv(fd, msg, HEADER_MESSAGE_SIZE, 0);	
}

#ifdef _MONITOR
static int monitor_socket = -1;

static void send_message_to_monitor(uint8_t *buf, size_t length)
{
	if (monitor_socket == -1) {
		/* initialize socket */
		struct sockaddr_un sun;
		char path[255];
		int len = -1;
		memset(path, 0, 255);
		monitor_socket = socket(AF_UNIX, SOCK_STREAM, 0);
		if (monitor_socket < 0)
			return ;
		sun.sun_family = AF_UNIX;
		strcpy(path, "/var/run/uloop/");
		strcat(path, "monitor");
		strcpy(sun.sun_path, path);

		len = strlen(sun.sun_path) + sizeof(sun.sun_family);
		if (connect(monitor_socket, (struct sockaddr *) &sun, len) < 0)
			return;
	}

	if (monitor_socket >= 0) {
		send_message(monitor_socket, buf, length);
	}
}

#endif

static UloopHeaderMessage *receive_header_message(int fd)
{
	ssize_t len = 0;
	uint8_t buf[HEADER_MESSAGE_SIZE]; // malloc the size of the standard message
	UloopHeaderMessage *genmsg = NULL;

	len = recv_header_message(fd, buf);

	if (len == -1) {
#ifdef ULOOP_DEBUG
		fprintf(stderr, "Received %zd bytes\n", len);
#endif
		return NULL;
	}

	if (len != HEADER_MESSAGE_SIZE)
		goto cleanup;/* something is not ok */
#ifdef ULOOP_DEBUG
	fprintf(stderr, "Parsing Message with %zd bytes\n", len);
#endif

	genmsg = uloop_header_message__unpack(NULL, len, buf);

	if (!genmsg) {
		fprintf(stderr, "Failed to unpack genmsg\n");
		goto cleanup;
	}

#ifdef _MONITOR
	send_message_to_monitor(buf, HEADER_MESSAGE_SIZE);
#endif
	return genmsg;

cleanup:
	return NULL;
}

UloopMessage *__recv_uloop_unix_msgs(int fd)
{
	uint8_t *buf_payload = NULL;
	UloopMessage *ulm = NULL;
	UloopHeaderMessage *uhm = receive_header_message(fd);

	if (!uhm) {
		fprintf(stderr, "Failed to unpack uloop header message\n");
		return NULL;
	}
#ifdef ULOOP_DEBUG
	fprintf(stderr, "Going to receive a message with %d bytes\n", uhm->length);
	print_message_header(uhm);
#endif

	if (uhm->length > 0) {
		buf_payload = malloc(uhm->length);
		ssize_t len_recv = recv(fd, buf_payload, uhm->length, 0);

		if (len_recv != uhm->length)
			return NULL;

		ulm = uloop_message__unpack(NULL, uhm->length, buf_payload);
	}
#ifdef _MONITOR
	send_message_to_monitor(buf_payload, uhm->length);
#endif

	if (uhm)
		uloop_header_message__free_unpacked(uhm, NULL);

	if (buf_payload != NULL)
		free(buf_payload);

	return ulm;
}

#ifdef _MONITOR
static UloopHeaderMessage *receive_header_message_monitor(int fd)
{
	ssize_t len = 0;
	uint8_t buf[HEADER_MESSAGE_SIZE]; // malloc the size of the standard message
	UloopHeaderMessage *genmsg = NULL;

	len = recv_header_message(fd, buf);

	if (len == -1) {
#ifdef ULOOP_DEBUG
		fprintf(stderr, "Received %zd bytes\n", len);
#endif
		return NULL;
	}

	if (len != HEADER_MESSAGE_SIZE)
		goto cleanup;/* something is not ok */
#ifdef ULOOP_DEBUG
	fprintf(stderr, "Parsing Message with %zd bytes\n", len);
#endif

	genmsg = uloop_header_message__unpack(NULL, len, buf);

	if (!genmsg) {
		fprintf(stderr, "Failed to unpack genmsg\n");
		goto cleanup;
	}

	return genmsg;

cleanup:
	return NULL;
}

UloopMessage *__recv_uloop_unix_msgs_monitor(int fd)
{
	uint8_t *buf_payload = NULL;
	UloopMessage *ulm = NULL;
	UloopHeaderMessage *uhm = receive_header_message_monitor(fd);

	if (!uhm) {
		fprintf(stderr, "Failed to unpack uloop header message\n");
		return NULL;
	}
#ifdef ULOOP_DEBUG
	fprintf(stderr, "Going to receive a message with %d bytes\n", uhm->length);
	print_message_header(uhm);
#endif

	if (uhm->length > 0) {
		buf_payload = malloc(uhm->length);
		ssize_t len_recv = recv(fd, buf_payload, uhm->length, 0);

		if (len_recv != uhm->length)
			return NULL;

		ulm = uloop_message__unpack(NULL, uhm->length, buf_payload);
	}

	if (uhm)
		uloop_header_message__free_unpacked(uhm, NULL);

	if (buf_payload != NULL)
		free(buf_payload);

	return ulm;
}
#endif
