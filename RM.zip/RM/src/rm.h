/*
 ============================================================================
 Name        : rm.h
 Author      : Luis Lopes (SITILABS, ULHT)
 Version     : 3.0.0
 Copyright   : ULOOP 2013
 Description : Global headers for the Resource Manager,
 	 	 	   task 3.2 / prototype version 3.0.0
 Date		 : June 2013
 ============================================================================
*/

#include "idhelper.h"
#include "cryptoid.h"

#include "uloop_message_api.h"

#include "uloop.pb-c.h"


#ifndef RM_H_
#define RM_H_

struct cac_data cac_info;

int call_RM();

#endif /* RM_H_ */
