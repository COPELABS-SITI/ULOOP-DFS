/*
 * Copyright (C) 2012 Caixa Magica Software.
 *
 * Authors:
 *	Alfredo Matos <alfredo.matos@caixamagica.pt>
 *	Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <openssl/sha.h>

#include "idhelper.h"
#include "cryptoid.h"
#include "nodeid.h"

int __cryptoid_compare(struct cryptoid *a, struct cryptoid *b)
{
	return memcmp(a->cryptoid, b->cryptoid , CRYPTO_ID_SIZE);
}

int __nodeid_compare(struct nodeid *a, struct nodeid *b)
{
	return memcmp(a->nodeid, b->nodeid, NODE_ID_SIZE);
}

/*
int cryptoid_to_unsigned_char(struct cryptoid *a, unsigned char ** buf)
{
	unsigned char tmp[CRYPTO_ID_SIZE];
	tmp = (unsigned char *) a;
	memcpy(buf, tmp, sizeof(tmp));
	return 0;
}
*/

void sha256(unsigned char **outputBuffer, const unsigned char *data, size_t len)
{
	if (outputBuffer == NULL || data == NULL || len == 0)
		return;

	SHA256_CTX sha256;

	SHA256_Init(&sha256);
	SHA256_Update(&sha256, data, len);
	SHA256_Final(*outputBuffer, &sha256);
}

void print_bytes(const unsigned char *hash, size_t size)
{
	int i = 0;
	for (i = 0; i < size; i++) {
		fprintf(stderr, "%02x", hash[i]);
	}
	fprintf(stderr, "\n");
}
