/*
 * Copyright (C) 2012 Caixa Magica Software.
 *
 * Authors:
 *	Alfredo Matos <alfredo.matos@caixamagica.pt>
 *	Nuno Martins  <nuno.martins@caixamagica.pt>
 *
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <openssl/err.h>

#include <openssl/sha.h>

#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/bn.h>

#include <openssl/evp.h>
#include <openssl/x509.h>

#include "cryptoid.h"
#include "idhelper.h"

static X509 *load_publickey_from_certificate(const char *filename)
{
	FILE *fp = NULL;
	X509 *x509_cert = NULL;

	if ((fp = fopen(filename, "rb")) == NULL) {
		fprintf(stdout, "error opening file %s\n", filename);
		return NULL;
	}
	PEM_read_X509(fp, &x509_cert, NULL, NULL);
	ERR_print_errors_fp(stdout);
	if (fp)
		fclose(fp);

	if (!x509_cert)
		return NULL;

	return x509_cert;
}

static unsigned char *__extract_pubkey_from_cert(X509 *x509_cert, int *length)
{
	int size = 0;
	EVP_PKEY * pubkey = NULL;
	unsigned char *buff = NULL;
	unsigned char *tmp = NULL;

	*length = 0;
	pubkey = X509_get_pubkey(x509_cert);
	ERR_print_errors_fp(stdout);

	if (pubkey) {
		size = i2d_PUBKEY(pubkey, NULL);
		buff = malloc(size);
		tmp = buff;
		size = i2d_PUBKEY(pubkey, &buff);
		*length = size;
		fprintf(stdout,"\n");
	}

	return tmp;
}

static unsigned char *__create_cryptoid(const char *filename, int *size)
{
	X509 *cert = NULL;
	*size = 0;

	cert = load_publickey_from_certificate(filename);

	if (!cert)
		return NULL;

	return __extract_pubkey_from_cert(cert, size);
}

struct cryptoid *create_crypto_ID(const char *filename)
{
	struct cryptoid *cid = NULL;
	cid = malloc(sizeof(*cid));
	int size = 0;
	memset(&(cid->cryptoid), 0, CRYPTO_ID_SIZE);
	unsigned char *data = __create_cryptoid(filename, &size);
	if (!data)
		return NULL;
	unsigned char *tmp2 = cid->cryptoid;
	sha256(&tmp2, data, size);
	free(data);

	return cid;
}

struct cryptoid *create_crypto_ID_str(unsigned char *cid_str)
{
	struct cryptoid *cid = NULL;

	return cid;
}

int compare_cryptoid(struct cryptoid *a, struct cryptoid *b)
{
	return __cryptoid_compare(a, b);
}

unsigned char *get_cryptoid_bytes(struct cryptoid *cid)
{
	return cid != NULL ? cid->cryptoid : NULL;
}
